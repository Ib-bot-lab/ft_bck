import { useState, useEffect } from "react";
import "./PaginatedTable.css";

/**
 * PaginatedTable
 *
 * Props:
 *  - data        : full array of items (already filtered/sorted by the parent)
 *  - columns     : [{ header: string, render: (row) => ReactNode, className?: string }]
 *  - pageSize    : default rows per page (default 20)
 *  - rowKey      : function (row) => unique key  (default (row, i) => i)
 *  - onRowClick  : optional (row) => void
 *  - emptyText   : shown when data is empty
 *  - mobileCard  : optional (row) => ReactNode  — renders card layout on mobile
 */
export default function PaginatedTable({
  data = [],
  columns = [],
  pageSize: defaultPageSize = 20,
  rowKey = (row, i) => i,
  onRowClick,
  emptyText = "No results found",
  mobileCard,
}) {
  const [page, setPage]           = useState(1);
  const [pageSize, setPageSize]   = useState(defaultPageSize);

  // Reset to page 1 whenever data changes (new filter/search result)
  useEffect(() => { setPage(1); }, [data]);

  const totalPages  = Math.max(1, Math.ceil(data.length / pageSize));
  const start       = (page - 1) * pageSize;
  const pageData    = data.slice(start, start + pageSize);

  const handlePrev  = () => setPage((p) => Math.max(1, p - 1));
  const handleNext  = () => setPage((p) => Math.min(totalPages, p + 1));

  // Build visible page numbers (max 5 buttons)
  const getPageNumbers = () => {
    const range = [];
    let startPage = Math.max(1, page - 2);
    let endPage   = Math.min(totalPages, startPage + 4);
    if (endPage - startPage < 4) startPage = Math.max(1, endPage - 4);
    for (let i = startPage; i <= endPage; i++) range.push(i);
    return range;
  };

  return (
    <div className="pt-wrapper">
      {/* ── Table (desktop) ── */}
      <div className="pt-table-container desktop-only">
        <table className="pt-table">
          <thead>
            <tr>
              {columns.map((col, i) => (
                <th key={i} className={col.className || ""}>{col.header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageData.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="pt-empty">{emptyText}</td>
              </tr>
            ) : (
              pageData.map((row, i) => (
                <tr
                  key={rowKey(row, start + i)}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={onRowClick ? "pt-row-clickable" : ""}
                >
                  {columns.map((col, ci) => (
                    <td key={ci} className={col.className || ""}>{col.render(row)}</td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* ── Mobile cards ── */}
      {mobileCard && (
        <div className="pt-mobile-cards mobile-only">
          {pageData.length === 0 ? (
            <p className="pt-empty">{emptyText}</p>
          ) : (
            pageData.map((row, i) => (
              <div key={rowKey(row, start + i)}>
                {mobileCard(row)}
              </div>
            ))
          )}
        </div>
      )}

      {/* ── Pagination bar ── */}
      <div className="pt-pagination">
        <div className="pt-pagination-info">
          Showing {data.length === 0 ? 0 : start + 1}–{Math.min(start + pageSize, data.length)} of {data.length}
        </div>

        <div className="pt-pagination-controls">
          <button className="pt-page-btn" onClick={() => setPage(1)} disabled={page === 1} title="First">«</button>
          <button className="pt-page-btn" onClick={handlePrev} disabled={page === 1} title="Previous">‹</button>

          {getPageNumbers().map((n) => (
            <button
              key={n}
              className={`pt-page-btn ${n === page ? "active" : ""}`}
              onClick={() => setPage(n)}
            >
              {n}
            </button>
          ))}

          <button className="pt-page-btn" onClick={handleNext} disabled={page === totalPages} title="Next">›</button>
          <button className="pt-page-btn" onClick={() => setPage(totalPages)} disabled={page === totalPages} title="Last">»</button>
        </div>

        <div className="pt-page-size">
          <label>Rows:</label>
          <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}>
            {[10, 20, 50, 100].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
      </div>
    </div>
  );
}
