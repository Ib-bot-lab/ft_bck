import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "./Ticketing.css";

const API = import.meta.env.VITE_BACKEND_URL;

const STATUS_COLORS = {
  open:        { bg: "#fef3c7", color: "#92400e", label: "Open" },
  in_progress: { bg: "#dbeafe", color: "#1e40af", label: "In Progress" },
  resolved:    { bg: "#dcfce7", color: "#166534", label: "Resolved" },
};

function formatDate(str) {
  if (!str) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  }).format(new Date(str));
}

export default function SMSManagement() {
  const navigate = useNavigate();
  const [tickets, setTickets]         = useState([]);
  const [loading, setLoading]         = useState(true);
  const [filter, setFilter]           = useState("all");
  const [search, setSearch]           = useState("");
  const [selected, setSelected]       = useState(null);
  const [reply, setReply]             = useState("");
  const [sending, setSending]         = useState(false);
  const [updating, setUpdating]       = useState(false);
  const messagesEndRef                = useRef(null);

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) { navigate("/"); return; }
    loadTickets();
  }, [navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [selected?.messages]);

  const token = () => localStorage.getItem("adminToken");

  const loadTickets = async () => {
    try {
      setLoading(true);
      const res  = await fetch(`${API}/api/admin/support-tickets/list`, {
        headers: { Authorization: `Bearer ${token()}` },
      });
      const data = await res.json();
      if (!data.success) { console.error(data.error); return; }
      setTickets(data.data);
    } catch (e) {
      console.error("Error loading tickets:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectTicket = (ticket) => {
    setSelected(ticket);
    setReply("");
  };

  const handleSendReply = async () => {
    if (!reply.trim() || !selected) return;
    setSending(true);
    try {
      const res  = await fetch(`${API}/api/admin/support-tickets/${selected.id}/messages`, {
        method:  "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token()}` },
        body:    JSON.stringify({ text: reply.trim() }),
      });
      const data = await res.json();
      if (!data.success) { alert(data.error || "Failed to send reply"); return; }
      setSelected(data.data);
      setTickets((prev) => prev.map((t) => t.id === data.data.id ? data.data : t));
      setReply("");
    } catch (e) {
      alert("Failed to send reply");
    } finally {
      setSending(false);
    }
  };

  const handleUpdateStatus = async (status) => {
    if (!selected) return;
    setUpdating(true);
    try {
      const res  = await fetch(`${API}/api/admin/support-tickets/${selected.id}/status`, {
        method:  "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token()}` },
        body:    JSON.stringify({ status }),
      });
      const data = await res.json();
      if (!data.success) { alert(data.error || "Failed to update status"); return; }
      setSelected(data.data);
      setTickets((prev) => prev.map((t) => t.id === data.data.id ? data.data : t));
    } catch (e) {
      alert("Failed to update status");
    } finally {
      setUpdating(false);
    }
  };

  const filtered = tickets.filter((t) => {
    const matchStatus = filter === "all" || t.status === filter;
    const matchSearch = !search ||
      t.id.toLowerCase().includes(search.toLowerCase()) ||
      t.userEmail.toLowerCase().includes(search.toLowerCase()) ||
      t.category.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  const counts = {
    all:         tickets.length,
    open:        tickets.filter((t) => t.status === "open").length,
    in_progress: tickets.filter((t) => t.status === "in_progress").length,
    resolved:    tickets.filter((t) => t.status === "resolved").length,
  };

  return (
    <div className="ticketing-page">
      {/* ── Header ── */}
      <div className="ticketing-header">
        <div className="ticketing-header-left">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <div>
            <h1>Support Tickets</h1>
            <p>Manage and respond to user support requests</p>
          </div>
        </div>
        <button className="ticketing-refresh-btn" onClick={loadTickets} disabled={loading}>
          <svg className={loading ? "spin" : ""} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="23 4 23 10 17 10" /><polyline points="1 20 1 14 7 14" />
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
          </svg>
          Refresh
        </button>
      </div>

      {/* ── Stats ── */}
      <div className="ticketing-stats">
        {[
          { key: "all",         label: "Total"       },
          { key: "open",        label: "Open"        },
          { key: "in_progress", label: "In Progress" },
          { key: "resolved",    label: "Resolved"    },
        ].map((s) => (
          <div key={s.key} className="ticketing-stat-card"
            onClick={() => setFilter(s.key)}>
            <span className="stat-number">{counts[s.key]}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>

      {/* ── Main layout ── */}
      <div className="ticketing-layout">

        {/* ── Left: ticket list ── */}
        <div className="ticket-list-panel">
          {/* Filters */}
          <div className="ticket-list-filters">
            <input
              className="ticket-search"
              placeholder="Search by ID, email, category…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <div className="ticket-filter-tabs">
              {["all", "open", "in_progress", "resolved"].map((f) => (
                <button key={f} className={`filter-tab ${filter === f ? "active" : ""}`}
                  onClick={() => setFilter(f)}>
                  {f === "in_progress" ? "In Progress" : f.charAt(0).toUpperCase() + f.slice(1)}
                  <span className="filter-count">{counts[f]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* List */}
          {loading ? (
            <div className="ticket-list-empty">
              <div className="loading-spinner-sm" />
              <p>Loading tickets…</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="ticket-list-empty">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ccc" strokeWidth="1.5">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
              <p>No tickets found</p>
            </div>
          ) : (
            <div className="ticket-list">
              {filtered.map((ticket) => {
                const s = STATUS_COLORS[ticket.status] || STATUS_COLORS.open;
                const isActive = selected?.id === ticket.id;
                return (
                  <div key={ticket.id}
                    className={`ticket-list-item ${isActive ? "active" : ""}`}
                    onClick={() => handleSelectTicket(ticket)}>
                    <div className="ticket-item-top">
                      <span className="ticket-item-id">{ticket.id}</span>
                      <span className="ticket-item-status" style={{ background: s.bg, color: s.color }}>
                        {s.label}
                      </span>
                    </div>
                    <p className="ticket-item-email">{ticket.userEmail}</p>
                    <p className="ticket-item-category">{ticket.category} · {ticket.subIssue}</p>
                    <p className="ticket-item-date">{formatDate(ticket.createdAt)}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Right: ticket detail ── */}
        {selected ? (
          <div className="ticket-detail-panel">
            {/* Detail header */}
            <div className="ticket-detail-header">
              <div className="ticket-detail-header-left">
                <h2>{selected.id}</h2>
                <p>{selected.userEmail}</p>
              </div>
              <div className="ticket-detail-actions">
                {selected.status !== "resolved" && (
                  <button className="status-btn status-btn-resolve"
                    onClick={() => handleUpdateStatus("resolved")} disabled={updating}>
                    {updating ? "Saving…" : "Mark Resolved"}
                  </button>
                )}
                {selected.status === "resolved" && (
                  <button className="status-btn status-btn-reopen"
                    onClick={() => handleUpdateStatus("open")} disabled={updating}>
                    {updating ? "Saving…" : "Reopen"}
                  </button>
                )}
                {selected.status === "open" && (
                  <button className="status-btn status-btn-progress"
                    onClick={() => handleUpdateStatus("in_progress")} disabled={updating}>
                    {updating ? "Saving…" : "Set In Progress"}
                  </button>
                )}
              </div>
            </div>

            {/* Ticket meta */}
            <div className="ticket-meta">
              <div className="ticket-meta-item">
                <span className="meta-label">Category</span>
                <span className="meta-value">{selected.category}</span>
              </div>
              <div className="ticket-meta-item">
                <span className="meta-label">Sub Issue</span>
                <span className="meta-value">{selected.subIssue}</span>
              </div>
              <div className="ticket-meta-item">
                <span className="meta-label">Status</span>
                <span className="meta-value">
                  <span style={{
                    background: STATUS_COLORS[selected.status]?.bg,
                    color: STATUS_COLORS[selected.status]?.color,
                    padding: "2px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600,
                  }}>
                    {STATUS_COLORS[selected.status]?.label}
                  </span>
                </span>
              </div>
              <div className="ticket-meta-item">
                <span className="meta-label">Created</span>
                <span className="meta-value">{formatDate(selected.createdAt)}</span>
              </div>
            </div>

            {/* Attachments */}
            {selected.attachments?.length > 0 && (
              <div className="ticket-attachments">
                <span className="meta-label">Attachments</span>
                <div className="attachments-list">
                  {selected.attachments.map((url, i) => (
                    <a key={i} href={url} target="_blank" rel="noreferrer" className="attachment-link">
                      📎 Attachment {i + 1}
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Messages thread */}
            <div className="ticket-messages">
              {selected.messages?.map((msg, i) => (
                <div key={i} className={`message-bubble ${msg.sender === "support" ? "support" : "user"}`}>
                  <div className="message-sender">
                    {msg.sender === "support" ? "Support (You)" : selected.userEmail}
                  </div>
                  <div className="message-text">{msg.text}</div>
                  {msg.createdAt && (
                    <div className="message-time">{formatDate(msg.createdAt)}</div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Reply box */}
            {selected.status !== "resolved" ? (
              <div className="ticket-reply-box">
                <textarea
                  className="reply-textarea"
                  placeholder="Type your reply…"
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) handleSendReply(); }}
                  rows={3}
                />
                <div className="reply-footer">
                  <span className="reply-hint">Ctrl+Enter to send</span>
                  <button className="reply-send-btn" onClick={handleSendReply}
                    disabled={sending || !reply.trim()}>
                    {sending ? "Sending…" : "Send Reply"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="ticket-resolved-banner">
                ✅ This ticket is resolved. Reopen it to send more replies.
              </div>
            )}
          </div>
        ) : (
          <div className="ticket-detail-empty">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="#ccc" strokeWidth="1.2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            <p>Select a ticket to view the conversation</p>
          </div>
        )}
      </div>
    </div>
  );
}
