export { default } from "./LoyaltyTab";
