export { default } from "./AppearancePanel";
