export { default } from "./AppointmentDetailsPanel";
