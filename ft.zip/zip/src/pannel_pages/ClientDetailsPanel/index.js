export { default } from "./ClientDetailsPanel";
