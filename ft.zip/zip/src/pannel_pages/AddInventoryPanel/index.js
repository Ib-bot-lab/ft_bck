export { default } from "./AddInventoryPanel";
