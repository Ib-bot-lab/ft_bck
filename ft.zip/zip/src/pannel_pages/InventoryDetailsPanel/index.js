export { default } from "./InventoryDetailsPanel";
