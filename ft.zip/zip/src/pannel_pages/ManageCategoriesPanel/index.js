export { default } from "./ManageCategoriesPanel";
