export { default } from "./DesignDetailsPanel";
