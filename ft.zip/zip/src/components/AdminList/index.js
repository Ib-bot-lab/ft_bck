export { default } from "./AdminList";
