export { default } from "./OTPInput";
