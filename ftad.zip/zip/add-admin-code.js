// Script to add admin codes to Firebase
// Run this file with: node add-admin-code.js

import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp,
} from "firebase/firestore";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBcl7hy63ZNw3mXiJTrL7EoWqdy44eWzHk",
  authDomain: "fashiontallycloud.firebaseapp.com",
  projectId: "fashiontallycloud",
  storageBucket: "fashiontallycloud.firebasestorage.app",
  messagingSenderId: "203645598940",
  appId: "1:203645598940:web:1c52d0a8f9a27c1c704819",
  measurementId: "G-W9HLR3B4CM",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to add admin code
async function addAdminCode(code, description = "") {
  try {
    const docRef = await addDoc(collection(db, "admin_login_credential"), {
      code: code,
      isActive: true,
      createdAt: serverTimestamp(),
      createdBy: "script",
      description: description,
    });
    console.log("✅ Admin code added successfully!");
    console.log("Document ID:", docRef.id);
    console.log("Code:", code);
    console.log("Description:", description);
    return docRef.id;
  } catch (error) {
    console.error("❌ Error adding admin code:", error);
    throw error;
  }
}

// Add your admin codes here
const adminCodes = [
  { code: "ADMIN2024", description: "Main admin access" },
  { code: "TEST123", description: "Test admin code" },
  // Add more codes as needed
];

// Execute
async function main() {
  console.log("🚀 Starting to add admin codes...\n");

  for (const { code, description } of adminCodes) {
    await addAdminCode(code, description);
    console.log("---");
  }

  console.log("\n✨ All codes added successfully!");
  console.log("You can now use these codes to login to the admin panel.");
  process.exit(0);
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
