// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

console.log("=== FIREBASE CONFIG DEBUG ===");

// Your web app's Firebase configuration using environment variables
const firebaseConfig = {
  apiKey:
    import.meta.env.VITE_FIREBASE_API_KEY ||
    "AIzaSyBcl7hy63ZNw3mXiJTrL7EoWqdy44eWzHk",
  authDomain:
    import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ||
    "fashiontallycloud.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "fashiontallycloud",
  storageBucket:
    import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ||
    "fashiontallycloud.firebasestorage.app",
  messagingSenderId:
    import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "203645598940",
  appId:
    import.meta.env.VITE_FIREBASE_APP_ID ||
    "1:203645598940:web:1c52d0a8f9a27c1c704819",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-W9HLR3B4CM",
};

console.log("Firebase Config:", {
  apiKey: firebaseConfig.apiKey
    ? "***" + firebaseConfig.apiKey.slice(-4)
    : "missing",
  authDomain: firebaseConfig.authDomain,
  projectId: firebaseConfig.projectId,
  storageBucket: firebaseConfig.storageBucket,
});

// Initialize Firebase
console.log("Initializing Firebase app...");
const app = initializeApp(firebaseConfig);
console.log("Firebase app initialized:", !!app);

console.log("Initializing Firestore...");
export const db = getFirestore(app);
console.log("Firestore initialized:", !!db);
console.log("=== FIREBASE CONFIG COMPLETE ===");
