import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";

function Login() {
  const [code, setCode]         = useState("");
  const [newCode, setNewCode]   = useState("");
  const [label, setLabel]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [checking, setChecking] = useState(true); // checking if code exists
  const [isSetup, setIsSetup]   = useState(false); // true = no code in DB yet
  const [error, setError]       = useState("");
  const [success, setSuccess]   = useState("");
  const navigate = useNavigate();

  const API = import.meta.env.VITE_BACKEND_URL;

  useEffect(() => {
    if (localStorage.getItem("adminAuth") === "true") {
      navigate("/dashboard");
      return;
    }
    // Check if any admin code exists in DB
    fetch(`${API}/api/admin/has-code`)
      .then(r => r.json())
      .then(data => {
        setIsSetup(!data.hasCode);
        setChecking(false);
      })
      .catch(() => setChecking(false));
  }, [navigate, API]);

  // ── Login ──────────────────────────────────────────
  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    if (!code.trim()) { setError("Please enter a code"); return; }

    setLoading(true);
    try {
      const res  = await fetch(`${API}/api/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        localStorage.setItem("adminAuth", "true");
        localStorage.setItem("adminToken", data.token);
        localStorage.setItem("adminLoginTime", new Date().toISOString());
        navigate("/dashboard");
      } else {
        setError(data.error || "Invalid code. Please try again.");
      }
    } catch {
      setError("An error occurred. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  // ── First-time setup ───────────────────────────────
  const handleSetup = async (e) => {
    e.preventDefault();
    setError(""); setSuccess("");
    if (!newCode.trim()) { setError("Please enter a code"); return; }
    if (newCode.trim().length < 6) { setError("Code must be at least 6 characters"); return; }

    setLoading(true);
    try {
      const res  = await fetch(`${API}/api/admin/setup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: newCode.trim(), label: label.trim() || "Admin" }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccess("Admin code set! You can now log in.");
        setIsSetup(false);
        setNewCode(""); setLabel("");
      } else {
        setError(data.error || "Setup failed. Please try again.");
      }
    } catch {
      setError("An error occurred. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="admin-login-container">
        <div className="admin-login-left-section">
          <div className="admin-login-left-content">
            <h1 className="admin-login-brand">Admin Panel</h1>
            <p className="admin-login-tagline">Manage Your Platform</p>
          </div>
        </div>
        <div className="admin-login-right-section">
          <div className="admin-login-right-content" style={{ textAlign: "center" }}>
            <span className="spinner" style={{ width: 32, height: 32, borderWidth: 3, display: "inline-block" }} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-login-container">
      <div className="admin-login-left-section">
        <div className="admin-login-left-content">
          <h1 className="admin-login-brand">Admin Panel</h1>
          <p className="admin-login-tagline">
            {isSetup ? "First-Time Setup" : "Manage Your Platform"}
          </p>
        </div>
      </div>

      <div className="admin-login-right-section">
        <div className="admin-login-right-content">
          <div className="admin-login-header">
            <h1 className="admin-login-title">
              {isSetup ? "Set Admin Code" : "Welcome Back"}
            </h1>
            <p className="admin-login-subtitle">
              {isSetup
                ? "No admin code found. Create one to get started."
                : "Sign in to admin dashboard"}
            </p>
          </div>

          {/* ── Setup form ── */}
          {isSetup ? (
            <form onSubmit={handleSetup}>
              <div className="admin-input-group">
                <input
                  type="text"
                  placeholder="New admin code (min. 6 characters)"
                  value={newCode}
                  onChange={e => { setNewCode(e.target.value); setError(""); }}
                  className={`admin-login-input ${error ? "error" : ""}`}
                  disabled={loading}
                  autoFocus
                />
              </div>
              <div className="admin-input-group">
                <input
                  type="text"
                  placeholder="Label (optional, e.g. Super Admin)"
                  value={label}
                  onChange={e => setLabel(e.target.value)}
                  className="admin-login-input"
                  disabled={loading}
                />
              </div>
              {error   && <span className="admin-error-message">{error}</span>}
              {success && <span className="admin-success-message">{success}</span>}
              <button type="submit" className="admin-login-btn" disabled={loading}>
                {loading ? (
                  <span className="admin-loading-spinner"><span className="spinner" />Saving…</span>
                ) : "Set Code & Continue"}
              </button>
            </form>

          ) : (
          /* ── Login form ── */
            <form onSubmit={handleLogin}>
              <div className="admin-input-group">
                <input
                  type="text"
                  placeholder="Enter admin code"
                  value={code}
                  onChange={e => { setCode(e.target.value); setError(""); }}
                  className={`admin-login-input ${error ? "error" : ""}`}
                  required
                  disabled={loading}
                  autoFocus
                />
                {error   && <span className="admin-error-message">{error}</span>}
                {success && <span className="admin-success-message">{success}</span>}
              </div>
              <button type="submit" className="admin-login-btn" disabled={loading}>
                {loading ? (
                  <span className="admin-loading-spinner"><span className="spinner" />Verifying...</span>
                ) : "Continue"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default Login;
