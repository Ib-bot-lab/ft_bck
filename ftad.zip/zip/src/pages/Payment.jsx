import "./PageStyles.css";

function Payment() {
  return (
    <div className="page-container">
      <h2>Payment</h2>
      <div className="content-card">
        <p>Payment management content goes here</p>
      </div>
    </div>
  );
}

export default Payment;
