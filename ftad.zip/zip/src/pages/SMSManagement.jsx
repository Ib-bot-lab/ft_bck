import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./PageStyles.css";

export default function SMSManagement() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div className="admin-page">
      <div className="page-header">
        <div>
          <h1 className="page-title">SMS Management</h1>
          <p className="page-subtitle">
            Manage SMS notifications and messaging
          </p>
        </div>
      </div>

      <div className="content-card">
        <p>SMS Management features coming soon...</p>
      </div>
    </div>
  );
}
