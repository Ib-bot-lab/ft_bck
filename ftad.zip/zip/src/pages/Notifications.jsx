import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./ActiveUsers.css";
import "./Notifications.css";

const API       = import.meta.env.VITE_BACKEND_URL;
const getToken  = () => localStorage.getItem("adminToken");
const authHdrs  = () => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${getToken()}`,
});

const BellIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);

const SendIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="22" y1="2" x2="11" y2="13" />
    <polygon points="22 2 15 22 11 13 2 9 22 2" />
  </svg>
);

export default function Notifications() {
  const navigate = useNavigate();

  // ── history ───────────────────────────────────────────────────
  const [history, setHistory]               = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  // ── side panel ────────────────────────────────────────────────
  const [panelOpen, setPanelOpen] = useState(false);
  const [title, setTitle]         = useState("");
  const [body, setBody]           = useState("");
  const [sending, setSending]     = useState(false);
  const [sendResult, setSendResult] = useState(null);

  // ── detail panel (view a past notification) ───────────────────
  const [selected, setSelected] = useState(null);

  // ── daily job manual trigger ──────────────────────────────────
  const [runningDaily, setRunningDaily] = useState(false);
  const [dailyMsg, setDailyMsg]         = useState("");
  // ── auth guard ────────────────────────────────────────────────
  useEffect(() => {
    if (!localStorage.getItem("adminAuth")) navigate("/");
  }, [navigate]);

  // ── load history ─────────────────────────────────────────────
  const loadHistory = useCallback(async () => {
    setLoadingHistory(true);
    try {
      const res  = await fetch(`${API}/api/admin/notifications`, { headers: authHdrs() });
      const data = await res.json();
      if (data.success) setHistory(data.data);
    } catch (err) {
      console.error("Failed to load notification history:", err);
    } finally {
      setLoadingHistory(false);
    }
  }, []);

  useEffect(() => { loadHistory(); }, [loadHistory]);

  // ── open / close compose panel ───────────────────────────────
  const openPanel = () => {
    setTitle("");
    setBody("");
    setSendResult(null);
    setSelected(null);
    setPanelOpen(true);
  };
  const closePanel = () => {
    if (sending) return;
    setPanelOpen(false);
    setSendResult(null);
  };

  // ── open detail panel ────────────────────────────────────────
  const openDetail = (item) => {
    setSelected(item);
    setPanelOpen(false);
  };
  const closeDetail = () => setSelected(null);

  // ── send broadcast ───────────────────────────────────────────
  const handleSend = async (e) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    setSending(true);
    setSendResult(null);
    try {
      const res  = await fetch(`${API}/api/admin/notifications/send`, {
        method:  "POST",
        headers: authHdrs(),
        body:    JSON.stringify({ title: title.trim(), body: body.trim() }),
      });
      const data = await res.json();
      setSendResult(data);
      if (data.success) {
        setTitle("");
        setBody("");
        loadHistory();
      }
    } catch {
      setSendResult({ success: false, message: "Network error. Please try again." });
    } finally {
      setSending(false);
    }
  };

  // ── trigger daily job manually ───────────────────────────────
  const handleRunDaily = async () => {
    setRunningDaily(true);
    setDailyMsg("");
    try {
      const res  = await fetch(`${API}/api/admin/notifications/run-daily`, {
        method: "POST", headers: authHdrs(),
      });
      const data = await res.json();
      setDailyMsg(data.success ? "✅ Daily job triggered — check server logs." : `❌ ${data.error}`);
    } catch {
      setDailyMsg("❌ Network error.");
    } finally {
      setRunningDaily(false);
      setTimeout(() => setDailyMsg(""), 6000);
    }
  };

  // ── helpers ───────────────────────────────────────────────────
  const fmt = (str) => {
    if (!str) return "—";
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric", month: "short", day: "numeric",
      hour: "2-digit", minute: "2-digit",
    }).format(new Date(str));
  };

  const DeliveryBar = ({ delivered, targeted }) => {
    const pct = targeted > 0 ? Math.round((delivered / targeted) * 100) : 0;
    const color = pct >= 80 ? "#10b981" : pct >= 50 ? "#f59e0b" : "#ef4444";
    return (
      <div className="notif_bar_wrap" title={`${delivered} / ${targeted} delivered`}>
        <div className="notif_bar_track">
          <div className="notif_bar_fill" style={{ width: `${pct}%`, background: color }} />
        </div>
        <span className="notif_bar_pct">{pct}%</span>
      </div>
    );
  };

  // ── render ────────────────────────────────────────────────────
  return (
    <div className="active-users-page">

      {/* ── Page header ─────────────────────────────────────── */}
      <div className="users-header">
        <div className="header-content">
          <div className="header-title-section">
            <BellIcon className="header-icon" />
            <div>
              <h1 className="users-title">Push Notifications</h1>
              <p className="users-subtitle">Broadcast messages to all users with notifications enabled</p>
            </div>
          </div>
          <div className="header-actions">
            <button className="refresh-button" onClick={loadHistory} disabled={loadingHistory}>
              <svg className={loadingHistory ? "spin" : ""} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="23 4 23 10 17 10" /><polyline points="1 20 1 14 7 14" />
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
              </svg>
              Refresh
            </button>
            <button
              className="notif_run_btn"
              onClick={handleRunDaily}
              disabled={runningDaily}
              title="Manually trigger the daily low-stock / appointment / orders job"
            >
              {runningDaily ? (
                <><span className="notif_spinner" style={{ borderTopColor: "#0d9488", borderColor: "#99f6e4" }} /> Running…</>
              ) : (
                <>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="5 3 19 12 5 21 5 3"/>
                  </svg>
                  Run Daily Job
                </>
              )}
            </button>
            {dailyMsg && <span className="notif_daily_msg">{dailyMsg}</span>}
            <button className="notif_new_btn" onClick={openPanel}>
              <SendIcon />
              Send Notification
            </button>
          </div>
        </div>
      </div>

      {/* ── History card ────────────────────────────────────── */}
      <div className="users-card">
        <div className="users-card-header">
          <div className="card-header-content">
            <h3 className="card-title">
              Sent Notifications
              <span className="card-badge">{history.length} total</span>
            </h3>
            <p className="card-description">All broadcast notifications you've sent, with delivery stats.</p>
          </div>
        </div>

        {loadingHistory ? (
          <div className="loading-container" style={{ minHeight: "240px" }}>
            <div className="loading-spinner" />
            <p className="loading-text">Loading history…</p>
          </div>
        ) : history.length === 0 ? (
          <div className="empty-state">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            <h3>No notifications sent yet</h3>
            <p>Click "Send Notification" to broadcast your first message.</p>
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="users-table-container">
              <table className="users-table desktop-only">
                <thead>
                  <tr>
                    <th>Title &amp; Message</th>
                    <th>Sent At</th>
                    <th>Targeted</th>
                    <th>Delivered</th>
                    <th>Failed</th>
                    <th>Delivery Rate</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((item) => (
                    <tr key={item.id} onClick={() => openDetail(item)}>
                      <td>
                        <div className="notif_title_cell">{item.title}</div>
                        <div className="notif_body_preview">{item.body}</div>
                      </td>
                      <td><div className="date-cell">{fmt(item.sentAt)}</div></td>
                      <td><span className="notif_num">{item.totalTargeted}</span></td>
                      <td><span className="notif_num notif_green">{item.delivered}</span></td>
                      <td><span className={`notif_num ${item.failed > 0 ? "notif_red" : "notif_muted"}`}>{item.failed}</span></td>
                      <td><DeliveryBar delivered={item.delivered} targeted={item.totalTargeted} /></td>
                      <td>
                        <div className="action-buttons">
                          <button
                            className="action-btn view-btn"
                            onClick={(e) => { e.stopPropagation(); openDetail(item); }}
                            title="View details"
                          >
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                              <circle cx="12" cy="12" r="3"/>
                            </svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="users-mobile-cards mobile-only">
              {history.map((item) => (
                <div key={item.id} className="user-mobile-card" onClick={() => openDetail(item)}>
                  <div className="mobile-card-header" style={{ alignItems: "flex-start" }}>
                    <div className="user-avatar" style={{ background: "linear-gradient(135deg,#14b8a6,#0d9488)" }}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                      </svg>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="user-name">{item.title}</div>
                      <div className="user-phone">{fmt(item.sentAt)}</div>
                    </div>
                  </div>
                  <div className="notif_body_preview" style={{ marginBottom: "0.75rem" }}>{item.body}</div>
                  <div className="notif_mobile_stats">
                    <div className="notif_mobile_stat"><span className="notif_mobile_stat_lbl">Targeted</span><span className="notif_num">{item.totalTargeted}</span></div>
                    <div className="notif_mobile_stat"><span className="notif_mobile_stat_lbl">Delivered</span><span className="notif_num notif_green">{item.delivered}</span></div>
                    <div className="notif_mobile_stat"><span className="notif_mobile_stat_lbl">Failed</span><span className={`notif_num ${item.failed > 0 ? "notif_red" : "notif_muted"}`}>{item.failed}</span></div>
                  </div>
                  <DeliveryBar delivered={item.delivered} targeted={item.totalTargeted} />
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* ═══════════════════════════════════════════════════════
          COMPOSE SIDE PANEL
      ═══════════════════════════════════════════════════════ */}
      {panelOpen && (
        <>
          <div className="panel-overlay" onClick={closePanel} />
          <div className="side-panel">

            {/* Panel header */}
            <div className="panel-header">
              <div className="panel-header-content">
                <h3 className="panel-title">Send Notification</h3>
                <p className="panel-subtitle">Broadcast a push message to all users</p>
              </div>
              <button className="panel-close" onClick={closePanel} disabled={sending}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Panel body */}
            <div className="panel-body">

              {/* Hero banner */}
              <div className="notif_panel_hero">
                <div className="notif_panel_hero_icon">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                </div>
                <div>
                  <div className="notif_panel_hero_title">Broadcast Message</div>
                  <div className="notif_panel_hero_sub">Delivered via FCM to all enabled devices</div>
                </div>
              </div>

              <form id="notif_compose_form" onSubmit={handleSend}>
                {/* Title field */}
                <div className="panel-section">
                  <h5 className="section-title">Notification Title</h5>
                  <div className="notif_field">
                    <input
                      type="text"
                      className="notif_input"
                      placeholder="e.g. New Feature Available"
                      value={title}
                      onChange={e => { setTitle(e.target.value); setSendResult(null); }}
                      maxLength={100}
                      required
                      disabled={sending}
                      autoFocus
                    />
                    <span className="notif_char">{title.length}/100</span>
                  </div>
                </div>

                {/* Body field */}
                <div className="panel-section">
                  <h5 className="section-title">Message</h5>
                  <div className="notif_field">
                    <textarea
                      className="notif_textarea"
                      placeholder="Write your message here…"
                      value={body}
                      onChange={e => { setBody(e.target.value); setSendResult(null); }}
                      maxLength={300}
                      required
                      disabled={sending}
                      rows={5}
                    />
                    <span className="notif_char">{body.length}/300</span>
                  </div>
                </div>

                {/* Preview */}
                {(title || body) && (
                  <div className="panel-section">
                    <h5 className="section-title">Preview</h5>
                    <div className="notif_preview">
                      <div className="notif_preview_dot" />
                      <div className="notif_preview_content">
                        <div className="notif_preview_title">{title || "Notification title"}</div>
                        <div className="notif_preview_body">{body || "Your message will appear here."}</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Result */}
                {sendResult && (
                  <div className={`notif_result ${sendResult.success ? "notif_result_ok" : "notif_result_err"}`}>
                    {sendResult.success ? (
                      <>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                        <span>
                          Sent! <strong>{sendResult.targeted}</strong> targeted — <strong>{sendResult.delivered}</strong> delivered
                          {sendResult.failed > 0 && <>, <strong>{sendResult.failed}</strong> failed</>}.
                        </span>
                      </>
                    ) : (
                      <>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        <span>{sendResult.error || sendResult.message}</span>
                      </>
                    )}
                  </div>
                )}
              </form>
            </div>

            {/* Panel footer */}
            <div className="panel-footer">
              <button className="panel-btn cancel-btn-panel" onClick={closePanel} disabled={sending}>
                Cancel
              </button>
              <button
                type="submit"
                form="notif_compose_form"
                className="panel-btn notif_send_btn"
                disabled={sending || !title.trim() || !body.trim()}
              >
                {sending ? (
                  <><span className="notif_spinner" /> Sending…</>
                ) : (
                  <><SendIcon /> Send to All Users</>
                )}
              </button>
            </div>
          </div>
        </>
      )}

      {/* ═══════════════════════════════════════════════════════
          DETAIL SIDE PANEL
      ═══════════════════════════════════════════════════════ */}
      {selected && (
        <>
          <div className="panel-overlay" onClick={closeDetail} />
          <div className="side-panel">

            <div className="panel-header">
              <div className="panel-header-content">
                <h3 className="panel-title">Notification Details</h3>
                <p className="panel-subtitle">{fmt(selected.sentAt)}</p>
              </div>
              <button className="panel-close" onClick={closeDetail}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className="panel-body">

              {/* Avatar header */}
              <div className="panel-user-header">
                <div className="panel-user-avatar">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                </div>
                <div className="panel-user-info">
                  <h4>{selected.title}</h4>
                  <p>{fmt(selected.sentAt)}</p>
                </div>
              </div>

              {/* Message */}
              <div className="panel-section">
                <h5 className="section-title">Message</h5>
                <div className="notif_detail_body">{selected.body}</div>
              </div>

              {/* Stats */}
              <div className="panel-section">
                <h5 className="section-title">Delivery Stats</h5>
                <div className="notif_stats_grid">
                  <div className="notif_stat_card notif_stat_blue">
                    <div className="notif_stat_value">{selected.totalTargeted}</div>
                    <div className="notif_stat_label">Targeted</div>
                  </div>
                  <div className="notif_stat_card notif_stat_green">
                    <div className="notif_stat_value">{selected.delivered}</div>
                    <div className="notif_stat_label">Delivered</div>
                  </div>
                  <div className="notif_stat_card notif_stat_red">
                    <div className="notif_stat_value">{selected.failed}</div>
                    <div className="notif_stat_label">Failed</div>
                  </div>
                </div>
                <div style={{ marginTop: "1rem" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem", fontSize: "0.875rem", color: "var(--text-secondary)" }}>
                    <span>Delivery rate</span>
                    <strong>{selected.deliveryRate}%</strong>
                  </div>
                  <div className="notif_bar_track" style={{ height: "10px" }}>
                    <div
                      className="notif_bar_fill"
                      style={{
                        width: `${selected.deliveryRate}%`,
                        background: selected.deliveryRate >= 80 ? "#10b981" : selected.deliveryRate >= 50 ? "#f59e0b" : "#ef4444",
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="panel-footer">
              <button className="panel-btn cancel-btn-panel" onClick={closeDetail}>Close</button>
              <button className="panel-btn notif_send_btn" onClick={() => { closeDetail(); openPanel(); }}>
                <SendIcon /> New Notification
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
