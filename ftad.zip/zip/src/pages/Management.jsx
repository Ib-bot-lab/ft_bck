import "./PageStyles.css";

function Management() {
  return (
    <div className="page-container">
      <h2>Management</h2>
      <div className="content-card">
        <p>General management content goes here</p>
      </div>
    </div>
  );
}

export default Management;
