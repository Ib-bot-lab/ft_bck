import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./SystemSettings.css";

const API = import.meta.env.VITE_BACKEND_URL;

// ── Tiny SVG bar chart (no library needed) ───────────────────────────────────
function SyncBarChart({ data, period }) {
  if (!data || data.length === 0) {
    return <div className="sync-graph-empty">No sync data yet</div>;
  }

  const maxVal = Math.max(...data.map(d => d.total || 0), 1);
  const W = 600, H = 140, PAD = 30;
  const barW = Math.max(4, Math.floor((W - PAD * 2) / data.length) - 2);

  return (
    <div className="sync-graph-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="sync-graph-svg" preserveAspectRatio="none">
        {data.map((d, i) => {
          const x = PAD + i * ((W - PAD * 2) / data.length);
          const h = Math.max(2, ((d.total || 0) / maxVal) * (H - 30));
          const y = H - h - 20;
          const label = period === 'day'
            ? d.date.slice(5)           // MM-DD
            : period === 'week'
            ? `W${getWeek(d.date)}`
            : d.date.slice(0, 7);       // YYYY-MM

          return (
            <g key={d.date}>
              <rect x={x} y={y} width={barW} height={h}
                fill="#6366f1" rx="2" opacity="0.85">
                <title>{d.date}: {d.total} events ({d.added} added, {d.modified} modified, {d.removed} removed)</title>
              </rect>
              {data.length <= 14 && (
                <text x={x + barW / 2} y={H - 4} textAnchor="middle"
                  fontSize="9" fill="#9ca3af">{label}</text>
              )}
            </g>
          );
        })}
        {/* Y-axis max label */}
        <text x={PAD - 4} y={20} textAnchor="end" fontSize="9" fill="#9ca3af">{maxVal}</text>
        <text x={PAD - 4} y={H - 20} textAnchor="end" fontSize="9" fill="#9ca3af">0</text>
      </svg>
    </div>
  );
}

function getWeek(dateStr) {
  const d = new Date(dateStr);
  const oneJan = new Date(d.getFullYear(), 0, 1);
  return Math.ceil(((d - oneJan) / 86400000 + oneJan.getDay() + 1) / 7);
}

// Group logs by week or month
function groupLogs(logs, period) {
  if (period === 'day') return logs;

  const groups = {};
  for (const d of logs) {
    let key;
    if (period === 'week') {
      const dt = new Date(d.date);
      const oneJan = new Date(dt.getFullYear(), 0, 1);
      const wk = Math.ceil(((dt - oneJan) / 86400000 + oneJan.getDay() + 1) / 7);
      key = `${dt.getFullYear()}-W${String(wk).padStart(2,'0')}`;
    } else {
      key = d.date.slice(0, 7);
    }
    if (!groups[key]) groups[key] = { date: key, added: 0, modified: 0, removed: 0, errors: 0, total: 0 };
    groups[key].added    += d.added    || 0;
    groups[key].modified += d.modified || 0;
    groups[key].removed  += d.removed  || 0;
    groups[key].errors   += d.errors   || 0;
    groups[key].total    += d.total    || 0;
  }
  return Object.values(groups).sort((a,b) => a.date.localeCompare(b.date));
}

// ── Sync Monitor Card ─────────────────────────────────────────────────────────
function SyncMonitorCard({ token }) {
  const [status,   setStatus]   = useState(null);
  const [logs,     setLogs]     = useState([]);
  const [period,   setPeriod]   = useState('day');   // day | week | month
  const [loading,  setLoading]  = useState(true);
  const [toggling, setToggling] = useState(false);
  const [shutting, setShutting] = useState(false);

  const headers = { Authorization: `Bearer ${token}` };

  const fetchAll = useCallback(async () => {
    try {
      const [sRes, lRes] = await Promise.all([
        fetch(`${API}/api/sync/status`, { headers }),
        fetch(`${API}/api/sync/logs?days=90`, { headers }),
      ]);
      const [s, l] = await Promise.all([sRes.json(), lRes.json()]);
      if (s.success) setStatus(s.data);
      if (l.success) setLogs(l.data);
    } catch (e) {
      console.error('sync fetch error', e);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchAll();
    const id = setInterval(fetchAll, 10000); // refresh every 10s
    return () => clearInterval(id);
  }, [fetchAll]);

  const handleToggle = async () => {
    if (!status) return;
    setToggling(true);
    try {
      const res  = await fetch(`${API}/api/sync/toggle`, {
        method: 'PUT',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !status.syncEnabled }),
      });
      const data = await res.json();
      if (data.success) setStatus(s => ({ ...s, syncEnabled: data.data.syncEnabled }));
    } finally {
      setToggling(false);
    }
  };

  const handleShutdown = async () => {
    if (!confirm('Stop all Firebase listeners? Sync will stop until server restarts.')) return;
    setShutting(true);
    try {
      await fetch(`${API}/api/sync/shutdown`, { method: 'POST', headers });
      setStatus(s => ({ ...s, listenersActive: false }));
      alert('Listeners stopped. Restart the server to re-activate sync.');
    } finally {
      setShutting(false);
    }
  };

  // Determine badge
  const getBadge = () => {
    if (!status) return null;
    if (status.isRunning)       return <span className="sync-badge syncing"><span className="sync-dot"/>Initial sync running…</span>;
    if (!status.syncEnabled)    return <span className="sync-badge inactive"><span className="sync-dot"/>Sync disabled</span>;
    if (!status.listenersActive)return <span className="sync-badge inactive"><span className="sync-dot"/>Listeners stopped</span>;
    return <span className="sync-badge active"><span className="sync-dot"/>Live — syncing in real-time</span>;
  };

  // Build chart data based on period
  const chartData = groupLogs(logs, period);

  // Session totals from logs (all time)
  const totals = logs.reduce((a, d) => ({
    added:    a.added    + (d.added    || 0),
    modified: a.modified + (d.modified || 0),
    removed:  a.removed  + (d.removed  || 0),
    errors:   a.errors   + (d.errors   || 0),
  }), { added: 0, modified: 0, removed: 0, errors: 0 });

  return (
    <div className="settings-card">
      <div className="card-header">
        <div className="card-header-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="23 4 23 10 17 10"/>
            <polyline points="1 20 1 14 7 14"/>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
          </svg>
        </div>
        <div>
          <h3 className="card-title">Firebase → MongoDB Sync Monitor</h3>
          <p className="card-description">Real-time sync status and historical activity</p>
        </div>
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Loading…</p>
      ) : (
        <div className="card-content">

          {/* Status bar */}
          <div className="sync-status-bar">
            {getBadge()}
            {status?.lastEventAt && (
              <span className="sync-last-event">
                Last event: {new Date(status.lastEventAt).toLocaleString()} — {status.lastEventType} in {status.lastCollection}
              </span>
            )}
          </div>

          {/* Period tabs */}
          <div className="sync-period-tabs">
            {['day','week','month'].map(p => (
              <button key={p} className={`sync-period-tab${period===p?' active':''}`}
                onClick={() => setPeriod(p)}>
                {p.charAt(0).toUpperCase()+p.slice(1)}
              </button>
            ))}
          </div>

          {/* Bar chart */}
          <SyncBarChart data={chartData} period={period} />

          {/* Stats */}
          <div className="sync-stats-row">
            <div className="sync-stat-box added">
              <div className="stat-val">{totals.added.toLocaleString()}</div>
              <div className="stat-lbl">Added</div>
            </div>
            <div className="sync-stat-box modified">
              <div className="stat-val">{totals.modified.toLocaleString()}</div>
              <div className="stat-lbl">Updated</div>
            </div>
            <div className="sync-stat-box removed">
              <div className="stat-val">{totals.removed.toLocaleString()}</div>
              <div className="stat-lbl">Deleted</div>
            </div>
            <div className="sync-stat-box errors">
              <div className="stat-val">{totals.errors.toLocaleString()}</div>
              <div className="stat-lbl">Errors</div>
            </div>
          </div>

          {/* Actions */}
          <div className="sync-actions">
            <button className="sync-btn refresh" onClick={fetchAll}>
              ↻ Refresh
            </button>
            <button
              className={`sync-btn ${status?.syncEnabled ? 'toggle-off' : 'toggle-on'}`}
              onClick={handleToggle} disabled={toggling}>
              {toggling ? '…' : status?.syncEnabled ? '⏸ Pause Sync' : '▶ Enable Sync'}
            </button>
            <button className="sync-btn shutdown" onClick={handleShutdown} disabled={shutting}>
              {shutting ? '…' : '⛔ Stop Listeners'}
            </button>
          </div>

          {/* Recent events */}
          {status?.recentEvents?.length > 0 && (
            <details>
              <summary className="sync-recent-title" style={{ cursor: 'pointer', userSelect: 'none' }}>
                Recent events (this session) — {status.recentEvents.length}
              </summary>
              <div className="sync-events-list" style={{ marginTop: '0.5rem' }}>
                {status.recentEvents.map((e, i) => (
                  <div key={i} className="sync-event-row">
                    <span className={`sync-event-type ${e.type}`}>{e.type}</span>
                    <span className="sync-event-col">{e.collection}</span>
                    <span className="sync-event-time">{new Date(e.timestamp).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </details>
          )}

        </div>
      )}
    </div>
  );
}

// ── Force Update Card ─────────────────────────────────────────────────────────
function ForceUpdateCard({ token }) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [form,    setForm]    = useState({
    forceUpdate:      false,
    minimumVersion:   '1.0.0',
    updateMessage:    'A new version is available. Please update the app to continue.',
    storeUrlAndroid:  '',
    storeUrlIos:      '',
  });

  const headers = { Authorization: `Bearer ${token}` };

  useEffect(() => {
    fetch(`${API}/api/system-setting/force-update`, { headers })
      .then(r => r.json())
      .then(d => {
        if (d.success) {
          setData(d.data);
          setForm(d.data);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res  = await fetch(`${API}/api/system-setting/force-update`, {
        method:  'PUT',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body:    JSON.stringify(form),
      });
      const d = await res.json();
      if (d.success) {
        setData(d.data);
        alert(form.forceUpdate
          ? `Force update ENABLED. Users on versions below ${form.minimumVersion} will be blocked.`
          : 'Force update disabled. All users can access the app.');
      } else {
        alert(d.error || 'Failed to save.');
      }
    } catch {
      alert('An error occurred.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return null;

  return (
    <div className="settings-card">
      <div className="card-header">
        <div className="card-header-icon" style={{ background: form.forceUpdate ? 'linear-gradient(135deg,#ef4444,#dc2626)' : undefined }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        </div>
        <div>
          <h3 className="card-title">Force App Update</h3>
          <p className="card-description">Block users on old versions until they update the mobile app</p>
        </div>
      </div>
      <div className="card-content">

        {/* Force update toggle */}
        <div className="setting-row">
          <div className="setting-info">
            <label className="setting-label">Force Update Active</label>
            <p className="setting-description">
              {form.forceUpdate
                ? `Users below v${form.minimumVersion} will see a blocking screen`
                : 'All app versions are allowed through'}
            </p>
          </div>
          <label className="toggle-switch">
            <input
              type="checkbox"
              checked={form.forceUpdate}
              onChange={e => setForm(f => ({ ...f, forceUpdate: e.target.checked }))}
            />
            <span className="toggle-slider" />
          </label>
        </div>

        {/* Fields */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <div className="cs-pin-field">
            <label className="setting-label">Minimum Version</label>
            <input
              className="cs-pin-input"
              placeholder="e.g. 1.2.0"
              value={form.minimumVersion}
              onChange={e => setForm(f => ({ ...f, minimumVersion: e.target.value }))}
            />
          </div>
          <div className="cs-pin-field">
            <label className="setting-label">Play Store URL (Android)</label>
            <input
              className="cs-pin-input"
              placeholder="https://play.google.com/store/apps/details?id=..."
              value={form.storeUrlAndroid}
              onChange={e => setForm(f => ({ ...f, storeUrlAndroid: e.target.value }))}
            />
          </div>
          <div className="cs-pin-field">
            <label className="setting-label">App Store URL (iOS)</label>
            <input
              className="cs-pin-input"
              placeholder="https://apps.apple.com/app/id..."
              value={form.storeUrlIos}
              onChange={e => setForm(f => ({ ...f, storeUrlIos: e.target.value }))}
            />
          </div>
          <div className="cs-pin-field" style={{ gridColumn: '1/-1' }}>
            <label className="setting-label">Update Message (shown to users)</label>
            <input
              className="cs-pin-input"
              placeholder="A new version is available. Please update to continue."
              value={form.updateMessage}
              onChange={e => setForm(f => ({ ...f, updateMessage: e.target.value }))}
            />
          </div>
        </div>

        {form.forceUpdate && (
          <div className="warning-message">
            ⚠️ Force update is ON. Users with version below <strong>{form.minimumVersion}</strong> will be blocked from using the app.
          </div>
        )}

        <button className="settings-btn cs-pin-btn" onClick={handleSave} disabled={saving}
          style={{ background: form.forceUpdate ? '#ef4444' : undefined, color: form.forceUpdate ? '#fff' : undefined, border: 'none' }}>
          {saving ? 'Saving…' : 'Save Force Update Settings'}
        </button>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function SystemSettings() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [subscriptionsEnabled, setSubscriptionsEnabled] = useState(true);
  const [subscriptionStateLoading, setSubscriptionStateLoading] =
    useState(true);
  const [subscriptionStateSaving, setSubscriptionStateSaving] = useState(false);

  // ── CS Pin state ──
  const [csPin,        setCsPin]        = useState('');
  const [csPinConfirm, setCsPinConfirm] = useState('');
  const [csPinSaving,  setCsPinSaving]  = useState(false);
  const [csPinError,   setCsPinError]   = useState('');
  const [csPinSuccess, setCsPinSuccess] = useState('');
  const [showPin,      setShowPin]      = useState(false);

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) {
      navigate("/");
      return;
    }
    fetchSubscriptionSetting();
  }, [navigate]);

  const fetchSubscriptionSetting = async () => {
    try {
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/system-setting/subscription`
      );
      const data = await res.json();
      if (data.success) {
        setSubscriptionsEnabled(data.data.subscriptionsEnabled !== false);
      }
    } catch (error) {
      console.error("Failed to load subscription settings:", error);
    } finally {
      setSubscriptionStateLoading(false);
      setLoading(false);
    }
  };

  const handleToggleSubscriptions = async (checked) => {
    setSubscriptionStateSaving(true);
    const previousValue = subscriptionsEnabled;
    setSubscriptionsEnabled(checked);

    try {
      const token = localStorage.getItem("adminToken");
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/system-setting/subscription`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({ subscriptionsEnabled: checked }),
        }
      );
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      alert(
        checked
          ? "Subscriptions enabled - Users will need an active subscription to access premium features."
          : "Subscriptions disabled - All users will now have access to every feature."
      );
    } catch (error) {
      console.error("Failed to update subscription settings:", error);
      setSubscriptionsEnabled(previousValue);
      alert("Update failed. Please try toggling the setting again.");
    } finally {
      setSubscriptionStateSaving(false);
    }
  };

  const handleUpdateCsPin = async (e) => {
    e.preventDefault();
    setCsPinError(''); setCsPinSuccess('');
    if (!csPin.trim()) { setCsPinError('Please enter a new pin'); return; }
    if (csPin.trim().length < 6) { setCsPinError('Pin must be at least 6 characters'); return; }
    if (csPin !== csPinConfirm) { setCsPinError('Pins do not match'); return; }

    setCsPinSaving(true);
    try {
      const token = localStorage.getItem('adminToken');
      const res   = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/cs-auth/update-pin`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ newPin: csPin.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setCsPinSuccess('Customer service pin updated successfully.');
        setCsPin(''); setCsPinConfirm('');
      } else {
        setCsPinError(data.error || 'Failed to update pin.');
      }
    } catch {
      setCsPinError('An error occurred. Please try again.');
    } finally {
      setCsPinSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="settings-page">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p className="loading-text">Loading Settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="settings-page">
      {/* Header */}
      <div className="settings-header">
        <div className="header-title-section">
          <svg
            className="header-icon"
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <circle cx="12" cy="12" r="3" />
            <path d="M12 1v6m0 6v6m5.2-13.2l-4.2 4.2m0 6l4.2 4.2M23 12h-6m-6 0H1m18.2 5.2l-4.2-4.2m0-6l4.2-4.2" />
          </svg>
          <div>
            <h1 className="settings-title">System Settings</h1>
            <p className="settings-subtitle">
              Configure system-wide settings and preferences
            </p>
          </div>
        </div>
      </div>

      {/* ── Sync Monitor ── */}
      <SyncMonitorCard token={localStorage.getItem('adminToken')} />

      {/* ── Force Update ── */}
      <ForceUpdateCard token={localStorage.getItem('adminToken')} />

      {/* CS Pin */}
      <div className="settings-card">
        <div className="card-header">
          <div className="card-header-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </div>
          <div>
            <h3 className="card-title">Customer Service Pin</h3>
            <p className="card-description">Change the login pin used by the customer service portal</p>
          </div>
        </div>
        <div className="card-content">
          <form onSubmit={handleUpdateCsPin} className="cs-pin-form">
            <div className="cs-pin-fields">
              <div className="cs-pin-field">
                <label className="setting-label">New Pin</label>
                <div className="cs-pin-input-wrap">
                  <input
                    type={showPin ? 'text' : 'password'}
                    placeholder="Min. 6 characters"
                    value={csPin}
                    onChange={e => { setCsPin(e.target.value); setCsPinError(''); setCsPinSuccess(''); }}
                    className={`cs-pin-input${csPinError ? ' cs-pin-input--error' : ''}`}
                    disabled={csPinSaving}
                  />
                </div>
              </div>
              <div className="cs-pin-field">
                <label className="setting-label">Confirm Pin</label>
                <div className="cs-pin-input-wrap">
                  <input
                    type={showPin ? 'text' : 'password'}
                    placeholder="Re-enter pin"
                    value={csPinConfirm}
                    onChange={e => { setCsPinConfirm(e.target.value); setCsPinError(''); setCsPinSuccess(''); }}
                    className={`cs-pin-input${csPinError ? ' cs-pin-input--error' : ''}`}
                    disabled={csPinSaving}
                  />
                </div>
              </div>
            </div>
            <label className="cs-pin-show">
              <input type="checkbox" checked={showPin} onChange={e => setShowPin(e.target.checked)} />
              Show pin
            </label>
            {csPinError   && <p className="cs-pin-msg cs-pin-msg--error">{csPinError}</p>}
            {csPinSuccess  && <p className="cs-pin-msg cs-pin-msg--success">{csPinSuccess}</p>}
            <button type="submit" className="settings-btn cs-pin-btn" disabled={csPinSaving}>
              {csPinSaving ? 'Updating…' : 'Update Pin'}
            </button>
          </form>
        </div>
      </div>

      {/* Subscription Control */}
      <div className="settings-card">
        <div className="card-header">
          <div className="card-header-icon">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
          </div>
          <div>
            <h3 className="card-title">Subscription Access</h3>
            <p className="card-description">
              Enable or disable subscription requirements for platform features
            </p>
          </div>
        </div>
        <div className="card-content">
          <div className="setting-row">
            <div className="setting-info">
              <label className="setting-label">
                Require Active Subscription
              </label>
              <p className="setting-description">
                {subscriptionsEnabled
                  ? "Users must have an active subscription to access premium functionality."
                  : "Subscriptions are disabled; every user has full access to all features."}
              </p>
            </div>
            <label className="toggle-switch">
              <input
                type="checkbox"
                checked={subscriptionsEnabled}
                onChange={(e) => handleToggleSubscriptions(e.target.checked)}
                disabled={subscriptionStateLoading || subscriptionStateSaving}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
          {!subscriptionsEnabled && (
            <div className="warning-message">
              Subscriptions are currently turned off. Consider re-enabling them
              once maintenance or promotions are complete.
            </div>
          )}
          {subscriptionStateSaving && (
            <p className="saving-text">Saving changes...</p>
          )}
        </div>
      </div>

      {/* Settings Grid */}
      <div className="settings-grid">
        {/* Security Settings */}
        <div className="settings-card">
          <div className="card-header">
            <div className="card-header-icon">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
            </div>
            <div>
              <h3 className="card-title">Security Settings</h3>
              <p className="card-description">
                Configure security and authentication settings
              </p>
            </div>
          </div>
          <div className="card-content">
            <div className="setting-row">
              <label className="setting-label">Two-Factor Authentication</label>
              <label className="toggle-switch">
                <input type="checkbox" />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">Enforce Strong Passwords</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">Auto Session Timeout</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <button className="settings-btn">
              Configure Security Policies
            </button>
          </div>
        </div>

        {/* Database Settings */}
        <div className="settings-card">
          <div className="card-header">
            <div className="card-header-icon">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <ellipse cx="12" cy="5" rx="9" ry="3" />
                <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
                <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
              </svg>
            </div>
            <div>
              <h3 className="card-title">Database Settings</h3>
              <p className="card-description">
                Manage database configuration and backups
              </p>
            </div>
          </div>
          <div className="card-content">
            <div className="setting-row">
              <label className="setting-label">Automatic Backups</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">Data Retention Policy</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">Query Logging</label>
              <label className="toggle-switch">
                <input type="checkbox" />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <button className="settings-btn">Create Manual Backup</button>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="settings-card">
          <div className="card-header">
            <div className="card-header-icon">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
            </div>
            <div>
              <h3 className="card-title">Notification Settings</h3>
              <p className="card-description">
                Configure system notifications and alerts
              </p>
            </div>
          </div>
          <div className="card-content">
            <div className="setting-row">
              <label className="setting-label">Email Notifications</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">System Alerts</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">User Activity Alerts</label>
              <label className="toggle-switch">
                <input type="checkbox" />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <button className="settings-btn">Configure Alert Rules</button>
          </div>
        </div>

        {/* Application Settings */}
        <div className="settings-card">
          <div className="card-header">
            <div className="card-header-icon">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="12" cy="12" r="10" />
                <line x1="2" y1="12" x2="22" y2="12" />
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
              </svg>
            </div>
            <div>
              <h3 className="card-title">Application Settings</h3>
              <p className="card-description">
                General application configuration
              </p>
            </div>
          </div>
          <div className="card-content">
            <div className="setting-row">
              <label className="setting-label">Maintenance Mode</label>
              <label className="toggle-switch">
                <input type="checkbox" />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">Allow User Registration</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <div className="setting-row">
              <label className="setting-label">Analytics Tracking</label>
              <label className="toggle-switch">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
            <button className="settings-btn">Update App Configuration</button>
          </div>
        </div>
      </div>

      {/* System Information */}
      <div className="settings-card">
        <div className="card-header">
          <div className="card-header-icon">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          </div>
          <div>
            <h3 className="card-title">System Information</h3>
            <p className="card-description">
              Current system status and information
            </p>
          </div>
        </div>
        <div className="card-content">
          <div className="info-grid">
            <div className="info-item">
              <label className="info-label">Application Version</label>
              <p className="info-value">v1.0.0</p>
            </div>
            <div className="info-item">
              <label className="info-label">Database Status</label>
              <p className="info-value status-connected">Connected</p>
            </div>
            <div className="info-item">
              <label className="info-label">Last Backup</label>
              <p className="info-value">2 hours ago</p>
            </div>
            <div className="info-item">
              <label className="info-label">Server Uptime</label>
              <p className="info-value">7 days, 14 hours</p>
            </div>
            <div className="info-item">
              <label className="info-label">Storage Used</label>
              <p className="info-value">2.4 GB / 10 GB</p>
            </div>
            <div className="info-item">
              <label className="info-label">Active Sessions</label>
              <p className="info-value">23 users</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
