import "./PageStyles.css";

function WebhookSMS() {
  return (
    <div className="page-container">
      <h2>Webhook SMS</h2>
      <div className="content-card">
        <p>Webhook SMS management content goes here</p>
      </div>
    </div>
  );
}

export default WebhookSMS;
