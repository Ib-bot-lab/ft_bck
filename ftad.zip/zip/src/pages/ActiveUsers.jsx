import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { createRoot } from "react-dom/client";
import "./ActiveUsers.css";

export default function ActiveUsers() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");
  const [userTypeFilter, setUserTypeFilter] = useState("all"); // all, users, admins
  const [selectedUser, setSelectedUser] = useState(null);
  const [showUserPanel, setShowUserPanel] = useState(false);
  const [panelMode, setPanelMode] = useState("view"); // view, edit
  const [editFormData, setEditFormData] = useState({});
  const [actionLoading, setActionLoading] = useState(false);
  const [exportingPDF, setExportingPDF] = useState(false);
  const [exportingCSV, setExportingCSV] = useState(false);

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) {
      navigate("/");
      return;
    }
    loadAllUsers();
  }, [navigate]);

  const loadAllUsers = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("adminToken");
      if (!token) { navigate("/"); return; }

      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/users/list`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();

      if (!data.success) {
        if (res.status === 401 || res.status === 403) {
          localStorage.removeItem("adminAuth");
          localStorage.removeItem("adminToken");
          navigate("/");
        }
        return;
      }

      setUsers(data.data.users);
      setAdmins(data.data.admins);
    } catch (error) {
      console.error("Error loading users:", error);
    } finally {
      setLoading(false);
    }
  };

  // Combine and filter users
  const getAllCombinedUsers = () => {
    let combined = [];

    if (userTypeFilter === "all" || userTypeFilter === "users") {
      combined = [...combined, ...users];
    }
    if (userTypeFilter === "all" || userTypeFilter === "admins") {
      combined = [...combined, ...admins];
    }

    return combined;
  };

  const getFilteredUsers = () => {
    let filtered = getAllCombinedUsers();

    // Search filter
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (user) =>
          user.email?.toLowerCase().includes(search) ||
          user.name?.toLowerCase().includes(search) ||
          user.businessName?.toLowerCase().includes(search) ||
          user.phoneNumber?.includes(search)
      );
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((user) => {
        const isActive = user.status === "active" || user.isActive !== false;
        return statusFilter === "active" ? isActive : !isActive;
      });
    }

    // Role filter
    if (roleFilter !== "all") {
      filtered = filtered.filter((user) => {
        if (user.userType === "admin") {
          return roleFilter === "admin";
        }
        return user.role?.toLowerCase() === roleFilter.toLowerCase();
      });
    }

    return filtered;
  };

  const filteredUsers = getFilteredUsers();

  // Get statistics
  const getStats = () => {
    const allUsers = getAllCombinedUsers();
    const total = allUsers.length;
    const active = allUsers.filter(
      (u) => u.status === "active" || u.isActive !== false
    ).length;
    const inactive = total - active;
    const totalAdmins = admins.length;

    // Calculate new users this month
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    const newThisMonth = allUsers.filter((user) => {
      if (!user.createdAt) return false;
      const userDate = user.createdAt.toDate
        ? user.createdAt.toDate()
        : new Date(user.createdAt);
      return (
        userDate.getMonth() === currentMonth &&
        userDate.getFullYear() === currentYear
      );
    }).length;

    return { total, active, inactive, admins: totalAdmins, newThisMonth };
  };

  const stats = getStats();

  const formatDate = (timestamp) => {
    if (!timestamp) return "Never";

    let date;
    if (timestamp.toDate) {
      date = timestamp.toDate();
    } else if (typeof timestamp === "string") {
      date = new Date(timestamp);
    } else if (timestamp instanceof Date) {
      date = timestamp;
    } else {
      return "Invalid date";
    }

    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  const handleViewUser = (user) => {
    setSelectedUser(user);
    setPanelMode("view");
    setShowUserPanel(true);
  };

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setPanelMode("edit");
    setEditFormData({
      name: user.name || "",
      email: user.email || "",
      phoneNumber: user.phoneNumber || "",
      role: user.role || "user",
      country: user.country || "",
      state: user.state || "",
    });
    setShowUserPanel(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedUser) return;
    try {
      setActionLoading(true);
      const token = localStorage.getItem("adminToken");
      const id = selectedUser.email || selectedUser.id;
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/users/edit/${selectedUser.userType}/${encodeURIComponent(id)}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            name: editFormData.name,
            phone: editFormData.phoneNumber,
            role: editFormData.role,
            country: editFormData.country,
            state: editFormData.state,
          }),
        }
      );
      const data = await res.json();
      if (data.success) {
        alert("User updated successfully!");
        setShowUserPanel(false);
        loadAllUsers();
      } else {
        alert(data.error || "Failed to update user.");
      }
    } catch (error) {
      console.error("Error updating user:", error);
      alert("Failed to update user. Please try again.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleStatus = async (user) => {
    const currentStatus = user.status === "active" || user.isActive !== false;
    const newStatus = !currentStatus;
    const action = newStatus ? "activate" : "deactivate";
    if (!confirm(`Are you sure you want to ${action} this user?`)) return;
    try {
      setActionLoading(true);
      const token = localStorage.getItem("adminToken");
      const id = user.email || user.id;
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/users/edit/${user.userType}/${encodeURIComponent(id)}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({ isActive: newStatus, status: newStatus ? "active" : "inactive" }),
        }
      );
      const data = await res.json();
      if (data.success) {
        alert(`User ${action}d successfully!`);
        setShowUserPanel(false);
        loadAllUsers();
      } else {
        alert(data.error || "Failed to update user status.");
      }
    } catch (error) {
      console.error("Error updating user status:", error);
      alert("Failed to update user status. Please try again.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUser = async (user) => {
    if (!confirm("Are you sure you want to DELETE this user? This action cannot be undone!")) return;
    if (!confirm("FINAL WARNING: This will permanently delete all user data. Continue?")) return;
    try {
      setActionLoading(true);
      const token = localStorage.getItem("adminToken");
      const id = user.email || user.id;
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/users/delete/${user.userType}/${encodeURIComponent(id)}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();
      if (data.success) {
        alert("User deleted successfully!");
        setShowUserPanel(false);
        loadAllUsers();
      } else {
        alert(data.error || "Failed to delete user.");
      }
    } catch (error) {
      console.error("Error deleting user:", error);
      alert("Failed to delete user. Please try again.");
    } finally {
      setActionLoading(false);
    }
  };

  // PDF Component for rendering user info
  const UserPDFComponent = ({ user }) => {
    const isSubAdmin = user.userType === "admin";
    const isActive = user.status === "active" || user.isActive !== false;

    return (
      <div
        style={{
          width: "1000px",
          fontSize: "14px",
          lineHeight: "1.6",
          color: "#333",
          backgroundColor: "white",
          padding: "48px",
        }}
      >
        {/* Header */}
        <div
          style={{
            borderBottom: "3px solid #3b82f6",
            paddingBottom: "24px",
            marginBottom: "32px",
          }}
        >
          <h1
            style={{
              fontSize: "36px",
              fontWeight: "bold",
              margin: "0 0 8px 0",
              color: "#1e293b",
            }}
          >
            User Information
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", margin: 0 }}>
            Generated on {new Date().toLocaleDateString()} at{" "}
            {new Date().toLocaleTimeString()}
          </p>
        </div>

        {/* User Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "24px",
            marginBottom: "32px",
            padding: "24px",
            backgroundColor: "#f8fafc",
            borderRadius: "12px",
          }}
        >
          <div
            style={{
              width: "80px",
              height: "80px",
              borderRadius: "50%",
              backgroundColor: "#3b82f6",
              color: "white",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "32px",
              fontWeight: "bold",
            }}
          >
            {user.name
              ? user.name.charAt(0).toUpperCase()
              : user.email.charAt(0).toUpperCase()}
          </div>
          <div style={{ flex: 1 }}>
            <h2
              style={{
                fontSize: "24px",
                fontWeight: "bold",
                margin: "0 0 8px 0",
                color: "#1e293b",
              }}
            >
              {user.name || "No name"}
            </h2>
            <p style={{ fontSize: "16px", color: "#64748b", margin: "0 0 12px 0" }}>
              {user.email}
            </p>
            <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
              <span
                style={{
                  padding: "4px 12px",
                  borderRadius: "12px",
                  fontSize: "12px",
                  fontWeight: "600",
                  backgroundColor: isActive ? "#dcfce7" : "#fee2e2",
                  color: isActive ? "#166534" : "#991b1b",
                }}
              >
                {isActive ? "Active" : "Inactive"}
              </span>
              <span
                style={{
                  padding: "4px 12px",
                  borderRadius: "12px",
                  fontSize: "12px",
                  fontWeight: "600",
                  backgroundColor: "#e0e7ff",
                  color: "#3730a3",
                }}
              >
                {user.role || "User"}
              </span>
              {isSubAdmin && (
                <span
                  style={{
                    padding: "4px 12px",
                    borderRadius: "12px",
                    fontSize: "12px",
                    fontWeight: "600",
                    backgroundColor: "#fef3c7",
                    color: "#92400e",
                  }}
                >
                  Sub-Admin
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div style={{ marginBottom: "32px" }}>
          <h3
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              marginBottom: "16px",
              color: "#1e293b",
              borderBottom: "2px solid #e2e8f0",
              paddingBottom: "8px",
            }}
          >
            Contact Information
          </h3>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <tbody>
              <tr>
                <td
                  style={{
                    padding: "12px 16px",
                    backgroundColor: "#f8fafc",
                    fontWeight: "600",
                    width: "200px",
                  }}
                >
                  Email Address
                </td>
                <td style={{ padding: "12px 16px" }}>{user.email}</td>
              </tr>
              {(user.phoneNumber || user.phone) && (
                <tr>
                  <td
                    style={{
                      padding: "12px 16px",
                      backgroundColor: "#f8fafc",
                      fontWeight: "600",
                    }}
                  >
                    Phone Number
                  </td>
                  <td style={{ padding: "12px 16px" }}>{user.phoneNumber || user.phone}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Business Information */}
        {user.businessName && (
          <div style={{ marginBottom: "32px" }}>
            <h3
              style={{
                fontSize: "18px",
                fontWeight: "bold",
                marginBottom: "16px",
                color: "#1e293b",
                borderBottom: "2px solid #e2e8f0",
                paddingBottom: "8px",
              }}
            >
              Business Information
            </h3>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td
                    style={{
                      padding: "12px 16px",
                      backgroundColor: "#f8fafc",
                      fontWeight: "600",
                      width: "200px",
                    }}
                  >
                    Business Name
                  </td>
                  <td style={{ padding: "12px 16px" }}>{user.businessName}</td>
                </tr>
                {user.businessCategory && (
                  <tr>
                    <td
                      style={{
                        padding: "12px 16px",
                        backgroundColor: "#f8fafc",
                        fontWeight: "600",
                      }}
                    >
                      Category
                    </td>
                    <td style={{ padding: "12px 16px" }}>
                      {user.businessCategory}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Location */}
        {(user.country || user.state) && (
          <div style={{ marginBottom: "32px" }}>
            <h3
              style={{
                fontSize: "18px",
                fontWeight: "bold",
                marginBottom: "16px",
                color: "#1e293b",
                borderBottom: "2px solid #e2e8f0",
                paddingBottom: "8px",
              }}
            >
              Location
            </h3>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {user.country && (
                  <tr>
                    <td
                      style={{
                        padding: "12px 16px",
                        backgroundColor: "#f8fafc",
                        fontWeight: "600",
                        width: "200px",
                      }}
                    >
                      Country
                    </td>
                    <td style={{ padding: "12px 16px" }}>{user.country}</td>
                  </tr>
                )}
                {user.state && (
                  <tr>
                    <td
                      style={{
                        padding: "12px 16px",
                        backgroundColor: "#f8fafc",
                        fontWeight: "600",
                      }}
                    >
                      State
                    </td>
                    <td style={{ padding: "12px 16px" }}>{user.state}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Subscription */}
        {(user.subscriptionType || user.planType) && (
          <div style={{ marginBottom: "32px" }}>
            <h3
              style={{
                fontSize: "18px",
                fontWeight: "bold",
                marginBottom: "16px",
                color: "#1e293b",
                borderBottom: "2px solid #e2e8f0",
                paddingBottom: "8px",
              }}
            >
              Subscription
            </h3>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {user.subscriptionType && (
                  <tr>
                    <td
                      style={{
                        padding: "12px 16px",
                        backgroundColor: "#f8fafc",
                        fontWeight: "600",
                        width: "200px",
                      }}
                    >
                      Subscription Type
                    </td>
                    <td style={{ padding: "12px 16px" }}>
                      {user.subscriptionType}
                    </td>
                  </tr>
                )}
                {user.planType && (
                  <tr>
                    <td
                      style={{
                        padding: "12px 16px",
                        backgroundColor: "#f8fafc",
                        fontWeight: "600",
                      }}
                    >
                      Plan Type
                    </td>
                    <td style={{ padding: "12px 16px" }}>{user.planType}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Account Details */}
        <div style={{ marginBottom: "32px" }}>
          <h3
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              marginBottom: "16px",
              color: "#1e293b",
              borderBottom: "2px solid #e2e8f0",
              paddingBottom: "8px",
            }}
          >
            Account Details
          </h3>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <tbody>
              <tr>
                <td
                  style={{
                    padding: "12px 16px",
                    backgroundColor: "#f8fafc",
                    fontWeight: "600",
                    width: "200px",
                  }}
                >
                  Created At
                </td>
                <td style={{ padding: "12px 16px" }}>
                  {formatDate(user.createdAt)}
                </td>
              </tr>
              {user.lastLogin && (
                <tr>
                  <td
                    style={{
                      padding: "12px 16px",
                      backgroundColor: "#f8fafc",
                      fontWeight: "600",
                    }}
                  >
                    Last Login
                  </td>
                  <td style={{ padding: "12px 16px" }}>
                    {formatDate(user.lastLogin)}
                  </td>
                </tr>
              )}
              {user.invitedBy && (
                <tr>
                  <td
                    style={{
                      padding: "12px 16px",
                      backgroundColor: "#f8fafc",
                      fontWeight: "600",
                    }}
                  >
                    Invited By
                  </td>
                  <td style={{ padding: "12px 16px" }}>{user.invitedBy}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Permissions (for sub-admins) */}
        {isSubAdmin && user.permissions && (
          <div style={{ marginBottom: "32px" }}>
            <h3
              style={{
                fontSize: "18px",
                fontWeight: "bold",
                marginBottom: "16px",
                color: "#1e293b",
                borderBottom: "2px solid #e2e8f0",
                paddingBottom: "8px",
              }}
            >
              Permissions
            </h3>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(2, 1fr)",
                gap: "12px",
              }}
            >
              {Object.entries(user.permissions).map(([key, value]) => (
                <div
                  key={key}
                  style={{
                    padding: "12px",
                    backgroundColor: value ? "#dcfce7" : "#fee2e2",
                    borderRadius: "8px",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                  }}
                >
                  <span
                    style={{
                      width: "20px",
                      height: "20px",
                      borderRadius: "50%",
                      backgroundColor: value ? "#166534" : "#991b1b",
                      color: "white",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "12px",
                      fontWeight: "bold",
                    }}
                  >
                    {value ? "✓" : "✗"}
                  </span>
                  <span style={{ fontSize: "14px", fontWeight: "500" }}>
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div
          style={{
            borderTop: "2px solid #e2e8f0",
            paddingTop: "24px",
            textAlign: "center",
            color: "#64748b",
            fontSize: "12px",
          }}
        >
          <p style={{ margin: 0 }}>
            This is a computer-generated document from FashionTally Admin System
          </p>
        </div>
      </div>
    );
  };

  // Handle PDF Export
  const handleExportPDF = async () => {
    if (!selectedUser) return;

    setExportingPDF(true);
    try {
      const tempContainer = document.createElement("div");
      tempContainer.style.position = "absolute";
      tempContainer.style.left = "-9999px";
      tempContainer.style.top = "0";
      document.body.appendChild(tempContainer);

      try {
        const root = createRoot(tempContainer);

        await new Promise((resolve) => {
          root.render(<UserPDFComponent user={selectedUser} />);
          setTimeout(resolve, 500);
        });

        const userElement = tempContainer.firstChild;
        const canvas = await html2canvas(userElement, {
          scale: 2,
          backgroundColor: "#ffffff",
          useCORS: true,
          logging: false,
          allowTaint: true,
        });

        const dataCanvas = canvas.toDataURL("image/png");

        const pdf = new jsPDF({
          orientation: "portrait",
          unit: "px",
          format: "a4",
        });

        const imgProperties = pdf.getImageProperties(dataCanvas);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight =
          (imgProperties.height * pdfWidth) / imgProperties.width;

        pdf.addImage(dataCanvas, "PNG", 0, 0, pdfWidth, pdfHeight);
        pdf.save(
          `user-${selectedUser.name?.replace(/\s+/g, "-") || selectedUser.email}.pdf`
        );

        root.unmount();
      } finally {
        document.body.removeChild(tempContainer);
      }
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("Failed to export PDF. Please try again.");
    } finally {
      setExportingPDF(false);
    }
  };

  const handleExportEmailsCSV = async () => {
    try {
      setExportingCSV(true);
      const token = localStorage.getItem("adminToken");
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/users/export-emails`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (!res.ok) {
        alert("Failed to export emails. Please try again.");
        return;
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "user_emails.csv";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error exporting emails:", error);
      alert("Failed to export emails. Please try again.");
    } finally {
      setExportingCSV(false);
    }
  };

  const closePanel = () => {
    setShowUserPanel(false);
    setSelectedUser(null);
    setPanelMode("view");
    setEditFormData({});
  };

  const resetFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setRoleFilter("all");
    setUserTypeFilter("all");
  };

  if (loading) {
    return (
      <div className="active-users-page">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p className="loading-text">Loading Users...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="active-users-page">
      {/* Header */}
      <div className="users-header">
        <div className="header-content">
          <div className="header-title-section">
            <svg
              className="header-icon"
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            <div>
              <h1 className="users-title">User Management</h1>
              <p className="users-subtitle">
                Manage all registered users and sub-admins
              </p>
            </div>
            <span className="users-count-badge">{stats.total}</span>
          </div>
          <div className="header-actions">
            <button
              className="refresh-button"
              onClick={loadAllUsers}
              disabled={loading}
            >
              <svg
                className={loading ? "spin" : ""}
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="23 4 23 10 17 10"></polyline>
                <polyline points="1 20 1 14 7 14"></polyline>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
              </svg>
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid-four">
        <div className="stat-card stat-card-blue">
          <div className="stat-card-header">
            <span className="stat-label">Total Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.total}</div>
          <div className="stat-footer">
            <svg
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
              <polyline points="17 6 23 6 23 12" />
            </svg>
            <span>All registered</span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-green">
          <div className="stat-card-header">
            <span className="stat-label">Active Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="8.5" cy="7" r="4" />
                <polyline points="17 11 19 13 23 9" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.active}</div>
          <div className="stat-footer">
            <span>
              {Math.round((stats.active / stats.total) * 100) || 0}% of total
            </span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-purple">
          <div className="stat-card-header">
            <span className="stat-label">Sub-Admins</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.admins}</div>
          <div className="stat-footer">
            <span>Team members</span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-orange">
          <div className="stat-card-header">
            <span className="stat-label">New This Month</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8" y1="2" x2="8" y2="6" />
                <line x1="3" y1="10" x2="21" y2="10" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.newThisMonth}</div>
          <div className="stat-footer">
            <span>Recent signups</span>
          </div>
          <div className="stat-decoration"></div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="users-card">
        <div className="users-card-header">
          <div className="card-header-content">
            <h3 className="card-title">
              Users List
              <span className="card-badge">{filteredUsers.length} shown</span>
            </h3>
            <p className="card-description">
              Real-time user management with advanced filtering
            </p>
          </div>
          <div className="card-header-actions">
            <button className="clear-filters-btn" onClick={resetFilters}>
              Clear Filters
            </button>
            <button
              className="export-emails-btn"
              onClick={handleExportEmailsCSV}
              disabled={exportingCSV}
              title="Download all user emails as CSV"
            >
              {exportingCSV ? (
                <>
                  <svg
                    className="spin"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <polyline points="23 4 23 10 17 10"></polyline>
                    <polyline points="1 20 1 14 7 14"></polyline>
                    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                  </svg>
                  Exporting...
                </>
              ) : (
                <>
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="7 10 12 15 17 10" />
                    <line x1="12" y1="15" x2="12" y2="3" />
                  </svg>
                  Download Emails CSV
                </>
              )}
            </button>
          </div>
        </div>

        <div className="filters-section">
          <div className="search-box">
            <svg
              className="search-icon"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
            <input
              type="text"
              placeholder="Search by email, name, business, or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>

          <select
            value={userTypeFilter}
            onChange={(e) => setUserTypeFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Types</option>
            <option value="users">Users Only</option>
            <option value="admins">Sub-Admins Only</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>

          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Roles</option>
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="business">Business</option>
          </select>
        </div>

        {/* Users Table */}
        <div className="users-table-container">
          {/* Desktop Table View */}
          <table className="users-table desktop-only">
            <thead>
              <tr>
                <th>User</th>
                <th>Email</th>
                <th>Type</th>
                <th>Role</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => {
                const isActive =
                  user.status === "active" || user.isActive !== false;
                const isSubAdmin = user.userType === "admin";

                return (
                  <tr
                    key={user.id}
                    onClick={() => handleViewUser(user)}
                    className="table-row"
                  >
                    <td>
                      <div className="user-cell">
                        <div className="user-avatar">
                          {user.name
                            ? user.name.charAt(0).toUpperCase()
                            : user.email.charAt(0).toUpperCase()}
                        </div>
                        <div className="user-info">
                          <div className="user-name">
                            {user.name || "No name"}
                          </div>
                          {user.businessName && (
                            <div className="user-business">
                              {user.businessName}
                            </div>
                          )}
                          {user.phoneNumber && (
                            <div className="user-phone">{user.phoneNumber}</div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="email-cell">
                        <svg
                          width="14"
                          height="14"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <rect x="2" y="4" width="20" height="16" rx="2" />
                          <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                        </svg>
                        <span>{user.email}</span>
                      </div>
                    </td>
                    <td>
                      {isSubAdmin ? (
                        <span className="type-badge admin-badge">
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path d="M12 2L2 7l10 5 10-5-10-5z" />
                            <path d="M2 17l10 5 10-5" />
                            <path d="M2 12l10 5 10-5" />
                          </svg>
                          Sub-Admin
                        </span>
                      ) : (
                        <span className="type-badge user-badge">
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                            <circle cx="12" cy="7" r="4" />
                          </svg>
                          User
                        </span>
                      )}
                    </td>
                    <td>
                      <span className="role-badge">{user.role || "User"}</span>
                    </td>
                    <td className="date-cell">
                      <svg
                        width="12"
                        height="12"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <rect
                          x="3"
                          y="4"
                          width="18"
                          height="18"
                          rx="2"
                          ry="2"
                        />
                        <line x1="16" y1="2" x2="16" y2="6" />
                        <line x1="8" y1="2" x2="8" y2="6" />
                        <line x1="3" y1="10" x2="21" y2="10" />
                      </svg>
                      {formatDate(user.createdAt)}
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button
                          className="action-btn view-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewUser(user);
                          }}
                          title="View Details"
                        >
                          <svg
                            width="14"
                            height="14"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                            <circle cx="12" cy="12" r="3" />
                          </svg>
                        </button>
                        <button
                          className="action-btn edit-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditUser(user);
                          }}
                          title="Edit User"
                        >
                          <svg
                            width="14"
                            height="14"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Mobile Card View */}
          <div className="users-mobile-cards mobile-only">
            {filteredUsers.map((user) => {
              const isActive =
                user.status === "active" || user.isActive !== false;
              const isSubAdmin = user.userType === "admin";

              return (
                <div
                  key={user.id}
                  className="user-mobile-card"
                  onClick={() => handleViewUser(user)}
                >
                  <div className="mobile-card-header">
                    <div className="user-avatar">
                      {user.name
                        ? user.name.charAt(0).toUpperCase()
                        : user.email.charAt(0).toUpperCase()}
                    </div>
                    <div className="mobile-card-info">
                      <div className="user-name">{user.name || "No name"}</div>
                      <div className="user-email">{user.email}</div>
                    </div>
                  </div>

                  <div className="mobile-card-body">
                    {user.businessName && (
                      <div className="mobile-info-row">
                        <svg
                          width="14"
                          height="14"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                          <polyline points="9 22 9 12 15 12 15 22" />
                        </svg>
                        <span>{user.businessName}</span>
                      </div>
                    )}
                    {user.phoneNumber && (
                      <div className="mobile-info-row">
                        <svg
                          width="14"
                          height="14"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                        </svg>
                        <span>{user.phoneNumber}</span>
                      </div>
                    )}
                  </div>

                  <div className="mobile-card-footer">
                    <div className="mobile-badges">
                      {isSubAdmin ? (
                        <span className="type-badge admin-badge">
                          Sub-Admin
                        </span>
                      ) : (
                        <span className="type-badge user-badge">User</span>
                      )}
                      <span className="role-badge">{user.role || "User"}</span>
                    </div>
                    <div className="mobile-action-buttons">
                      <button
                        className="action-btn-mobile view-btn-mobile"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleViewUser(user);
                        }}
                        title="View"
                      >
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                          <circle cx="12" cy="12" r="3" />
                        </svg>
                      </button>
                      <button
                        className="action-btn-mobile edit-btn-mobile"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEditUser(user);
                        }}
                        title="Edit"
                      >
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredUsers.length === 0 && (
            <div className="empty-state">
              <svg
                width="64"
                height="64"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              <h3>No users found</h3>
              <p>
                {searchTerm
                  ? "Try adjusting your search terms."
                  : "No users have been registered yet."}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* User Detail Side Panel */}
      {showUserPanel && selectedUser && (
        <>
          <div className="panel-overlay" onClick={closePanel}></div>
          <div className="side-panel">
            <div className="panel-header">
              <div className="panel-header-content">
                <h3 className="panel-title">
                  {panelMode === "edit" ? "Edit User" : "User Details"}
                </h3>
                <p className="panel-subtitle">
                  {selectedUser.userType === "admin" ? "Sub-Admin" : "User"}{" "}
                  Information
                </p>
              </div>
              <button className="panel-close" onClick={closePanel}>
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className="panel-body">
              {/* User Avatar and Basic Info */}
              <div className="panel-user-header">
                <div className="panel-user-avatar">
                  {selectedUser.name
                    ? selectedUser.name.charAt(0).toUpperCase()
                    : selectedUser.email.charAt(0).toUpperCase()}
                </div>
                <div className="panel-user-info">
                  <h4>{selectedUser.name || "No name"}</h4>
                  <p>{selectedUser.email}</p>
                  <div className="panel-user-badges">
                    <span
                      className={`status-badge ${
                        selectedUser.status === "active" ||
                        selectedUser.isActive !== false
                          ? "active"
                          : "inactive"
                      }`}
                    >
                      {selectedUser.status === "active" ||
                      selectedUser.isActive !== false
                        ? "Active"
                        : "Inactive"}
                    </span>
                    <span className="role-badge">
                      {selectedUser.role || "User"}
                    </span>
                    {selectedUser.userType === "admin" && (
                      <span className="type-badge admin-badge">Sub-Admin</span>
                    )}
                  </div>
                </div>
              </div>

              {panelMode === "view" ? (
                <>
                  {/* View Mode */}
                  <div className="panel-section">
                    <h5 className="section-title">Contact Information</h5>
                    <div className="info-grid">
                      {(selectedUser.phoneNumber || selectedUser.phone) && (
                        <div className="info-item">
                          <label>Phone Number</label>
                          <span>{selectedUser.phoneNumber || selectedUser.phone}</span>
                        </div>
                      )}
                      <div className="info-item">
                        <label>Email Address</label>
                        <span>{selectedUser.email}</span>
                      </div>
                    </div>
                  </div>

                  {selectedUser.businessName && (
                    <div className="panel-section">
                      <h5 className="section-title">Business Information</h5>
                      <div className="info-grid">
                        <div className="info-item">
                          <label>Business Name</label>
                          <span>{selectedUser.businessName}</span>
                        </div>
                        {selectedUser.businessCategory && (
                          <div className="info-item">
                            <label>Category</label>
                            <span>{selectedUser.businessCategory}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="panel-section">
                    <h5 className="section-title">Location</h5>
                    <div className="info-grid">
                      {selectedUser.country && (
                        <div className="info-item">
                          <label>Country</label>
                          <span>{selectedUser.country}</span>
                        </div>
                      )}
                      {selectedUser.state && (
                        <div className="info-item">
                          <label>State</label>
                          <span>{selectedUser.state}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {(selectedUser.subscriptionType || selectedUser.planType) && (
                    <div className="panel-section">
                      <h5 className="section-title">Subscription</h5>
                      <div className="info-grid">
                        {selectedUser.subscriptionType && (
                          <div className="info-item">
                            <label>Subscription Type</label>
                            <span>{selectedUser.subscriptionType}</span>
                          </div>
                        )}
                        {selectedUser.planType && (
                          <div className="info-item">
                            <label>Plan Type</label>
                            <span>{selectedUser.planType}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="panel-section">
                    <h5 className="section-title">Account Details</h5>
                    <div className="info-grid">
                      <div className="info-item">
                        <label>Created At</label>
                        <span>{formatDate(selectedUser.createdAt)}</span>
                      </div>
                      {selectedUser.lastLogin && (
                        <div className="info-item">
                          <label>Last Login</label>
                          <span>{formatDate(selectedUser.lastLogin)}</span>
                        </div>
                      )}
                      {selectedUser.invitedBy && (
                        <div className="info-item">
                          <label>Invited By</label>
                          <span>{selectedUser.invitedBy}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {selectedUser.userType === "admin" &&
                    selectedUser.permissions && (
                      <div className="panel-section">
                        <h5 className="section-title">Permissions</h5>
                        <div className="permissions-grid">
                          {Object.entries(selectedUser.permissions).map(
                            ([key, value]) => (
                              <div key={key} className="permission-item">
                                <div
                                  className={`permission-icon ${
                                    value ? "allowed" : "denied"
                                  }`}
                                >
                                  {value ? (
                                    <svg
                                      width="12"
                                      height="12"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                    >
                                      <polyline points="20 6 9 17 4 12" />
                                    </svg>
                                  ) : (
                                    <svg
                                      width="12"
                                      height="12"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                    >
                                      <line x1="18" y1="6" x2="6" y2="18" />
                                      <line x1="6" y1="6" x2="18" y2="18" />
                                    </svg>
                                  )}
                                </div>
                                <span>
                                  {key.charAt(0).toUpperCase() + key.slice(1)}
                                </span>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    )}
                </>
              ) : (
                <>
                  {/* Edit Mode */}
                  <div className="panel-section">
                    <h5 className="section-title">Edit User Information</h5>
                    <div className="edit-form">
                      <div className="form-group">
                        <label>Full Name</label>
                        <input
                          type="text"
                          value={editFormData.name}
                          onChange={(e) =>
                            setEditFormData({
                              ...editFormData,
                              name: e.target.value,
                            })
                          }
                          placeholder="Enter full name"
                        />
                      </div>

                      <div className="form-group">
                        <label>Email Address (Read-only)</label>
                        <input
                          type="email"
                          value={editFormData.email}
                          disabled
                          className="disabled-input"
                        />
                      </div>

                      <div className="form-group">
                        <label>Phone Number</label>
                        <input
                          type="tel"
                          value={editFormData.phoneNumber}
                          onChange={(e) =>
                            setEditFormData({
                              ...editFormData,
                              phoneNumber: e.target.value,
                            })
                          }
                          placeholder="Enter phone number"
                        />
                      </div>

                      <div className="form-group">
                        <label>Role</label>
                        <select
                          value={editFormData.role}
                          onChange={(e) =>
                            setEditFormData({
                              ...editFormData,
                              role: e.target.value,
                            })
                          }
                        >
                          <option value="user">User</option>
                          <option value="admin">Admin</option>
                          <option value="business">Business</option>
                        </select>
                      </div>

                      <div className="form-group">
                        <label>Country</label>
                        <input
                          type="text"
                          value={editFormData.country}
                          onChange={(e) =>
                            setEditFormData({
                              ...editFormData,
                              country: e.target.value,
                            })
                          }
                          placeholder="Enter country"
                        />
                      </div>

                      <div className="form-group">
                        <label>State</label>
                        <input
                          type="text"
                          value={editFormData.state}
                          onChange={(e) =>
                            setEditFormData({
                              ...editFormData,
                              state: e.target.value,
                            })
                          }
                          placeholder="Enter state"
                        />
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="panel-footer">
              {panelMode === "view" ? (
                <>
                  <button
                    className="panel-btn export-btn-panel"
                    onClick={handleExportPDF}
                    disabled={exportingPDF || actionLoading}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="7 10 12 15 17 10" />
                      <line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                    {exportingPDF ? "Generating PDF..." : "Export PDF"}
                  </button>
                  <button
                    className="panel-btn edit-btn-panel"
                    onClick={() => handleEditUser(selectedUser)}
                    disabled={actionLoading}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                    Edit User
                  </button>
                  <button
                    className="panel-btn delete-btn-panel"
                    onClick={() => handleDeleteUser(selectedUser)}
                    disabled={actionLoading}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <polyline points="3 6 5 6 21 6" />
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                      <line x1="10" y1="11" x2="10" y2="17" />
                      <line x1="14" y1="11" x2="14" y2="17" />
                    </svg>
                    Delete User
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="panel-btn cancel-btn-panel"
                    onClick={() => {
                      setPanelMode("view");
                      setEditFormData({});
                    }}
                    disabled={actionLoading}
                  >
                    Cancel
                  </button>
                  <button
                    className="panel-btn save-btn-panel"
                    onClick={handleSaveEdit}
                    disabled={actionLoading}
                  >
                    {actionLoading ? "Saving..." : "Save Changes"}
                  </button>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
