import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Subscriptions.css";

export default function Subscriptions() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedUser, setSelectedUser] = useState(null);
  const [showTrialPanel, setShowTrialPanel] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Trial form data
  const [trialForm, setTrialForm] = useState({
    planType: "Starter",
    months: 1,
    notes: "",
  });

  // Stats
  const [stats, setStats] = useState({
    totalUsers: 0,
    subscribedUsers: 0,
    trialUsers: 0,
    monthlyRevenue: 0,
  });

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) {
      navigate("/");
      return;
    }
    loadData();
  }, [navigate]);

  const loadData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("adminToken");
      if (!token) { navigate("/"); return; }

      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/subscriptions/list`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();

      if (!data.success) {
        if (res.status === 401 || res.status === 403) {
          localStorage.removeItem("adminAuth");
          localStorage.removeItem("adminToken");
          navigate("/");
        }
        return;
      }

      const usersList = data.data.users.map((u) => ({
        ...u,
        createdAt: u.createdAt ? new Date(u.createdAt) : new Date(),
        subscriptionStartDate: u.subscriptionStartDate ? new Date(u.subscriptionStartDate) : null,
        subscriptionEndDate: u.subscriptionEndDate ? new Date(u.subscriptionEndDate) : null,
      }));

      setUsers(usersList);
      setFilteredUsers(usersList);
      setStats(data.data.stats);
    } catch (error) {
      console.error("Error loading subscription data:", error);
      alert("Failed to load subscription data");
    } finally {
      setLoading(false);
    }
  };

  // Filter users
  useEffect(() => {
    let filtered = users;

    if (searchQuery) {
      const search = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (user) =>
          user.name.toLowerCase().includes(search) ||
          user.email.toLowerCase().includes(search) ||
          user.phone.includes(search)
      );
    }

    if (filterStatus !== "all") {
      filtered = filtered.filter(
        (user) => user.subscriptionType === filterStatus
      );
    }

    setFilteredUsers(filtered);
  }, [users, searchQuery, filterStatus]);

  const handleGrantTrial = async () => {
    if (!selectedUser) return;
    try {
      setActionLoading(true);
      const token = localStorage.getItem("adminToken");
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/subscriptions/grant-trial`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            email: selectedUser.email,
            planType: trialForm.planType,
            months: trialForm.months,
          }),
        }
      );
      const data = await res.json();
      if (data.success) {
        alert(`Trial subscription granted to ${selectedUser.name}`);
        setShowTrialPanel(false);
        setSelectedUser(null);
        setTrialForm({ planType: "Starter", months: 1, notes: "" });
        loadData();
      } else {
        alert(data.error || "Failed to grant trial subscription");
      }
    } catch (error) {
      console.error("Error granting trial:", error);
      alert("Failed to grant trial subscription");
    } finally {
      setActionLoading(false);
    }
  };

  const handleCancelSubscription = async (user) => {
    if (!confirm(`Are you sure you want to cancel subscription for ${user.name}?`)) return;
    try {
      setActionLoading(true);
      const token = localStorage.getItem("adminToken");
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/subscriptions/cancel`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({ email: user.email }),
        }
      );
      const data = await res.json();
      if (data.success) {
        alert(`Subscription cancelled for ${user.name}`);
        loadData();
      } else {
        alert(data.error || "Failed to cancel subscription");
      }
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      alert("Failed to cancel subscription");
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadge = (user) => {
    if (user.subscriptionType === "trial") {
      return <span className="status-badge trial">Trial</span>;
    } else if (user.subscriptionType === "paid") {
      return <span className="status-badge paid">Paid</span>;
    } else {
      return <span className="status-badge free">Free</span>;
    }
  };

  const getPlanBadgeClass = (plan) => {
    switch (plan) {
      case "Professional":
        return "plan-badge professional";
      case "Growth":
        return "plan-badge growth";
      case "Starter":
        return "plan-badge starter";
      default:
        return "plan-badge free";
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(value);
  };

  const formatDate = (date) => {
    if (!date) return "-";
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date);
  };

  const getDaysLeft = (endDate) => {
    if (!endDate) return null;
    const now = new Date();
    const diff = endDate - now;
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  const closePanel = () => {
    setShowTrialPanel(false);
    setSelectedUser(null);
    setTrialForm({ planType: "Starter", months: 1, notes: "" });
  };

  if (loading) {
    return (
      <div className="subscriptions-page">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p className="loading-text">Loading Subscriptions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="subscriptions-page">
      {/* Header */}
      <div className="subs-header">
        <div className="header-content">
          <div className="header-title-section">
            <svg
              className="header-icon"
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
            <div>
              <h1 className="subs-title">Subscriptions</h1>
              <p className="subs-subtitle">
                Manage user subscriptions and billing
              </p>
            </div>
          </div>
          <div className="header-actions">
            <button
              className="refresh-button"
              onClick={loadData}
              disabled={loading}
            >
              <svg
                className={loading ? "spin" : ""}
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="23 4 23 10 17 10"></polyline>
                <polyline points="1 20 1 14 7 14"></polyline>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
              </svg>
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid-four">
        <div className="stat-card stat-card-blue">
          <div className="stat-card-header">
            <span className="stat-label">Total Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.totalUsers}</div>
          <div className="stat-footer">
            <span>All registered</span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-green">
          <div className="stat-card-header">
            <span className="stat-label">Subscribed Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.subscribedUsers}</div>
          <div className="stat-footer">
            <span>
              {stats.totalUsers
                ? Math.round((stats.subscribedUsers / stats.totalUsers) * 100)
                : 0}
              % of total
            </span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-purple">
          <div className="stat-card-header">
            <span className="stat-label">Trial Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-6" />
                <path d="M12 2v10" />
                <path d="m8 8 4 4 4-4" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.trialUsers}</div>
          <div className="stat-footer">
            <span>Active trials</span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-orange">
          <div className="stat-card-header">
            <span className="stat-label">Monthly Revenue</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <line x1="12" y1="1" x2="12" y2="23" />
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
              </svg>
            </div>
          </div>
          <div className="stat-value">
            {formatCurrency(stats.monthlyRevenue)}
          </div>
          <div className="stat-footer">
            <span>From paid users</span>
          </div>
          <div className="stat-decoration"></div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="subs-card">
        <div className="subs-card-header">
          <div className="card-header-content">
            <h3 className="card-title">
              User Subscriptions
              <span className="card-badge">{filteredUsers.length} shown</span>
            </h3>
            <p className="card-description">
              Manage user subscription plans and billing
            </p>
          </div>
        </div>

        <div className="filters-section">
          <div className="search-box">
            <svg
              className="search-icon"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
            <input
              type="text"
              placeholder="Search by name, email, or phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Users</option>
            <option value="free">Free Users</option>
            <option value="trial">Trial Users</option>
            <option value="paid">Paid Users</option>
          </select>
        </div>

        {/* Subscriptions Table */}
        <div className="subs-table-container">
          <table className="subs-table desktop-only">
            <thead>
              <tr>
                <th>User</th>
                <th>Contact</th>
                <th>Status</th>
                <th>Plan</th>
                <th>Subscription Period</th>
                <th>Revenue</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => {
                const daysLeft = getDaysLeft(user.subscriptionEndDate);
                return (
                  <tr key={user.id}>
                    <td>
                      <div className="user-cell">
                        <div className="user-avatar">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="user-info">
                          <div className="user-name">{user.name}</div>
                          <div className="user-email">{user.email}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="contact-cell">
                        {user.phone && (
                          <div className="contact-row">
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                            >
                              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                            </svg>
                            {user.phone}
                          </div>
                        )}
                        <div className="contact-date">
                          Joined {formatDate(user.createdAt)}
                        </div>
                      </div>
                    </td>
                    <td>{getStatusBadge(user)}</td>
                    <td>
                      <span className={getPlanBadgeClass(user.planType)}>
                        {user.planType}
                      </span>
                    </td>
                    <td>
                      {user.subscriptionStartDate &&
                      user.subscriptionEndDate ? (
                        <div
                          className={`period-cell ${
                            user.subscriptionEndDate < new Date()
                              ? "expired"
                              : ""
                          }`}
                        >
                          <div className="period-dates">
                            {formatDate(user.subscriptionStartDate)} -{" "}
                            {formatDate(user.subscriptionEndDate)}
                          </div>
                          <div
                            className={`period-status ${
                              user.subscriptionEndDate < new Date()
                                ? "expired-status"
                                : ""
                            }`}
                          >
                            {daysLeft > 0
                              ? `${daysLeft} days left`
                              : user.subscriptionEndDate > new Date()
                              ? "Active"
                              : "Expired"}
                          </div>
                        </div>
                      ) : user.subscriptionEndDate ? (
                        <div
                          className={`period-cell ${
                            user.subscriptionEndDate < new Date()
                              ? "expired"
                              : ""
                          }`}
                        >
                          <div className="period-dates">
                            {formatDate(user.createdAt)} -{" "}
                            {formatDate(user.subscriptionEndDate)}
                          </div>
                          <div
                            className={`period-status ${
                              user.subscriptionEndDate < new Date()
                                ? "expired-status"
                                : ""
                            }`}
                          >
                            {daysLeft > 0 ? `${daysLeft} days left` : "Expired"}
                          </div>
                        </div>
                      ) : (
                        <span className="no-data">No subscription</span>
                      )}
                    </td>
                    <td className="revenue-cell">
                      {user.paymentAmount
                        ? formatCurrency(user.paymentAmount)
                        : "-"}
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button
                          className="action-btn grant-btn"
                          onClick={() => {
                            setSelectedUser(user);
                            setShowTrialPanel(true);
                          }}
                          title="Grant Trial"
                        >
                          <svg
                            width="14"
                            height="14"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path d="M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-6" />
                            <path d="M12 2v10" />
                            <path d="m8 8 4 4 4-4" />
                          </svg>
                        </button>
                        {user.isSubscribed && (
                          <button
                            className="action-btn cancel-btn"
                            onClick={() => handleCancelSubscription(user)}
                            disabled={actionLoading}
                            title="Cancel Subscription"
                          >
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                            >
                              <circle cx="12" cy="12" r="10" />
                              <line x1="15" y1="9" x2="9" y2="15" />
                              <line x1="9" y1="9" x2="15" y2="15" />
                            </svg>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Mobile Card View */}
          <div className="subs-mobile-cards mobile-only">
            {filteredUsers.map((user) => {
              const daysLeft = getDaysLeft(user.subscriptionEndDate);
              return (
                <div key={user.id} className="subs-mobile-card">
                  <div className="mobile-card-header">
                    <div className="user-avatar">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="mobile-card-info">
                      <div className="user-name">{user.name}</div>
                      <div className="user-email">{user.email}</div>
                    </div>
                  </div>

                  <div className="mobile-card-body">
                    <div className="mobile-info-row">
                      <span className="info-label">Status:</span>
                      {getStatusBadge(user)}
                    </div>
                    <div className="mobile-info-row">
                      <span className="info-label">Plan:</span>
                      <span className={getPlanBadgeClass(user.planType)}>
                        {user.planType}
                      </span>
                    </div>
                    {user.subscriptionEndDate && (
                      <div className="mobile-info-row">
                        <span className="info-label">Expires:</span>
                        <span>{formatDate(user.subscriptionEndDate)}</span>
                      </div>
                    )}
                    {user.paymentAmount > 0 && (
                      <div className="mobile-info-row">
                        <span className="info-label">Revenue:</span>
                        <span>{formatCurrency(user.paymentAmount)}</span>
                      </div>
                    )}
                  </div>

                  <div className="mobile-card-footer">
                    <button
                      className="mobile-action-btn grant-btn-mobile"
                      onClick={() => {
                        setSelectedUser(user);
                        setShowTrialPanel(true);
                      }}
                    >
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-6" />
                        <path d="M12 2v10" />
                        <path d="m8 8 4 4 4-4" />
                      </svg>
                      Grant Trial
                    </button>
                    {user.isSubscribed && (
                      <button
                        className="mobile-action-btn cancel-btn-mobile"
                        onClick={() => handleCancelSubscription(user)}
                        disabled={actionLoading}
                      >
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <circle cx="12" cy="12" r="10" />
                          <line x1="15" y1="9" x2="9" y2="15" />
                          <line x1="9" y1="9" x2="15" y2="15" />
                        </svg>
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {filteredUsers.length === 0 && (
            <div className="empty-state">
              <svg
                width="64"
                height="64"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
              <h3>No subscriptions found</h3>
              <p>
                {searchQuery
                  ? "Try adjusting your search terms."
                  : "No users have subscriptions yet."}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Grant Trial Side Panel */}
      {showTrialPanel && selectedUser && (
        <>
          <div className="panel-overlay" onClick={closePanel}></div>
          <div className="side-panel">
            <div className="panel-header">
              <div className="panel-header-content">
                <h3 className="panel-title">Grant Trial Subscription</h3>
                <p className="panel-subtitle">
                  Grant a trial subscription to {selectedUser.name}
                </p>
              </div>
              <button className="panel-close" onClick={closePanel}>
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className="panel-body">
              <div className="panel-user-header">
                <div className="panel-user-avatar">
                  {selectedUser.name.charAt(0).toUpperCase()}
                </div>
                <div className="panel-user-info">
                  <h4>{selectedUser.name}</h4>
                  <p>{selectedUser.email}</p>
                  <div className="panel-user-badges">
                    {getStatusBadge(selectedUser)}
                    <span className={getPlanBadgeClass(selectedUser.planType)}>
                      {selectedUser.planType}
                    </span>
                  </div>
                </div>
              </div>

              <div className="panel-section">
                <h5 className="section-title">Trial Details</h5>
                <div className="trial-form">
                  <div className="form-group">
                    <label>Plan Type</label>
                    <select
                      value={trialForm.planType}
                      onChange={(e) =>
                        setTrialForm({ ...trialForm, planType: e.target.value })
                      }
                      className="form-select"
                    >
                      <option value="Starter">Starter</option>
                      <option value="Growth">Growth</option>
                      <option value="Professional">Professional</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Duration</label>
                    <select
                      value={trialForm.months}
                      onChange={(e) =>
                        setTrialForm({
                          ...trialForm,
                          months: parseInt(e.target.value),
                        })
                      }
                      className="form-select"
                    >
                      <option value="1">1 Month</option>
                      <option value="2">2 Months</option>
                      <option value="3">3 Months</option>
                      <option value="6">6 Months</option>
                      <option value="12">12 Months</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Notes (Optional)</label>
                    <textarea
                      value={trialForm.notes}
                      onChange={(e) =>
                        setTrialForm({ ...trialForm, notes: e.target.value })
                      }
                      placeholder="Add any notes about this trial..."
                      className="form-textarea"
                      rows="4"
                    />
                  </div>
                </div>
              </div>

              {selectedUser.subscriptionEndDate && (
                <div className="panel-section">
                  <h5 className="section-title">Current Subscription</h5>
                  <div className="info-grid">
                    <div className="info-item">
                      <label>Current Plan</label>
                      <span>{selectedUser.planType}</span>
                    </div>
                    <div className="info-item">
                      <label>Expires On</label>
                      <span>
                        {formatDate(selectedUser.subscriptionEndDate)}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="panel-footer">
              <button
                className="panel-btn cancel-btn-panel"
                onClick={closePanel}
                disabled={actionLoading}
              >
                Cancel
              </button>
              <button
                className="panel-btn grant-btn-panel"
                onClick={handleGrantTrial}
                disabled={actionLoading}
              >
                {actionLoading ? "Granting..." : "Grant Trial"}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
