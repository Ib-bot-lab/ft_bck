import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Inbox.css";

export default function Inbox() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("contacts");
  const [contacts, setContacts] = useState([]);
  const [demos, setDemos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedItem, setSelectedItem] = useState(null);
  const [showPanel, setShowPanel] = useState(false);

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) { navigate("/"); return; }
    loadAll();
  }, [navigate]);

  const getToken = () => localStorage.getItem("adminToken");

  const loadAll = async () => {
    setLoading(true);
    try {
      const [cRes, dRes] = await Promise.all([
        fetch(`${import.meta.env.VITE_BACKEND_URL}/api/admin/inbox/contacts`, { headers: { Authorization: `Bearer ${getToken()}` } }),
        fetch(`${import.meta.env.VITE_BACKEND_URL}/api/admin/inbox/demos`, { headers: { Authorization: `Bearer ${getToken()}` } }),
      ]);
      const [cData, dData] = await Promise.all([cRes.json(), dRes.json()]);
      if (cData.success) setContacts(cData.data);
      if (dData.success) setDemos(dData.data);
    } catch (err) {
      console.error("Error loading inbox:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleViewItem = async (item, type) => {
    setSelectedItem({ ...item, _type: type });
    setShowPanel(true);

    if (!item.seen) {
      const endpoint = type === "contact"
        ? `/api/admin/inbox/contacts/${item.id}/seen`
        : `/api/admin/inbox/demos/${item.id}/seen`;
      try {
        await fetch(`${import.meta.env.VITE_BACKEND_URL}${endpoint}`, {
          method: "PUT",
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        if (type === "contact") {
          setContacts((prev) => prev.map((c) => c.id === item.id ? { ...c, seen: true } : c));
        } else {
          setDemos((prev) => prev.map((d) => d.id === item.id ? { ...d, seen: true } : d));
        }
        setSelectedItem((prev) => ({ ...prev, seen: true }));
      } catch (err) {
        console.error("Error marking seen:", err);
      }
    }
  };

  const closePanel = () => { setShowPanel(false); setSelectedItem(null); };

  const formatDate = (str) => {
    if (!str) return "—";
    return new Intl.DateTimeFormat("en-US", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(str));
  };

  const unseenContacts = contacts.filter((c) => !c.seen).length;
  const unseenDemos = demos.filter((d) => !d.seen).length;

  const filteredContacts = contacts.filter((c) =>
    !searchTerm || c.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.subject?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredDemos = demos.filter((d) =>
    !searchTerm || d.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.businessName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="active-users-page">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p className="loading-text">Loading Inbox...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="active-users-page">
      {/* Header */}
      <div className="users-header">
        <div className="header-content">
          <div className="header-title-section">
            <svg className="header-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
              <polyline points="22,6 12,13 2,6" />
            </svg>
            <div>
              <h1 className="users-title">Inbox</h1>
              <p className="users-subtitle">Contact messages and demo requests</p>
            </div>
          </div>
          <div className="header-actions">
            <button className="refresh-button" onClick={loadAll} disabled={loading}>
              <svg className={loading ? "spin" : ""} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="23 4 23 10 17 10"></polyline>
                <polyline points="1 20 1 14 7 14"></polyline>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
              </svg>
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="inbox-tabs">
        <button className={`inbox-tab-btn ${activeTab === "contacts" ? "active" : ""}`} onClick={() => { setActiveTab("contacts"); setSearchTerm(""); closePanel(); }}>
          Contact Messages
          {unseenContacts > 0 && <span className="inbox-unseen-badge">{unseenContacts}</span>}
        </button>
        <button className={`inbox-tab-btn ${activeTab === "demos" ? "active" : ""}`} onClick={() => { setActiveTab("demos"); setSearchTerm(""); closePanel(); }}>
          Demo Requests
          {unseenDemos > 0 && <span className="inbox-unseen-badge">{unseenDemos}</span>}
        </button>
      </div>

      {/* Card */}
      <div className="users-card">
        <div className="users-card-header">
          <div className="card-header-content">
            <h3 className="card-title">
              {activeTab === "contacts" ? "Contact Messages" : "Demo Requests"}
              <span className="card-badge">{activeTab === "contacts" ? filteredContacts.length : filteredDemos.length} shown</span>
            </h3>
          </div>
        </div>

        {/* Search */}
        <div className="filters-section" style={{ gridTemplateColumns: "1fr" }}>
          <div className="search-box">
            <svg className="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input type="text" className="search-input" placeholder={activeTab === "contacts" ? "Search by name, email or subject..." : "Search by name, email or business..."} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
        </div>

        {/* Table */}
        <div className="users-table-container">
          {activeTab === "contacts" ? (
            <table className="users-table desktop-only">
              <thead>
                <tr>
                  <th>From</th>
                  <th>Subject</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredContacts.length === 0 ? (
                  <tr><td colSpan="6"><div className="empty-state"><h3>No messages found</h3></div></td></tr>
                ) : filteredContacts.map((item) => (
                  <tr key={item.id} className={!item.seen ? "inbox-row-unseen" : ""} onClick={() => handleViewItem(item, "contact")}>
                    <td>
                      <div className="user-cell">
                        <div className="user-avatar" style={{ background: !item.seen ? "linear-gradient(135deg,#f59e0b,#d97706)" : undefined }}>
                          {item.name?.charAt(0).toUpperCase()}
                        </div>
                        <div className="user-info">
                          <div className="user-name">{item.name}</div>
                          <div className="user-phone">{item.email}</div>
                        </div>
                      </div>
                    </td>
                    <td>{item.subject || "—"}</td>
                    <td><span className={`inbox-priority-badge ${item.priority}`}>{item.priority}</span></td>
                    <td><span className={`status-badge ${item.seen ? "active" : "inactive"}`}>{item.seen ? "Seen" : "New"}</span></td>
                    <td><div className="date-cell">{formatDate(item.createdAt)}</div></td>
                    <td>
                      <div className="action-buttons">
                        <button className="action-btn view-btn" onClick={(e) => { e.stopPropagation(); handleViewItem(item, "contact"); }} title="View">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="users-table desktop-only">
              <thead>
                <tr>
                  <th>Requester</th>
                  <th>Business</th>
                  <th>Preferred Time</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredDemos.length === 0 ? (
                  <tr><td colSpan="6"><div className="empty-state"><h3>No demo requests found</h3></div></td></tr>
                ) : filteredDemos.map((item) => (
                  <tr key={item.id} className={!item.seen ? "inbox-row-unseen" : ""} onClick={() => handleViewItem(item, "demo")}>
                    <td>
                      <div className="user-cell">
                        <div className="user-avatar" style={{ background: !item.seen ? "linear-gradient(135deg,#f59e0b,#d97706)" : undefined }}>
                          {item.fullName?.charAt(0).toUpperCase()}
                        </div>
                        <div className="user-info">
                          <div className="user-name">{item.fullName}</div>
                          <div className="user-phone">{item.email}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="user-name">{item.businessName || "—"}</div>
                      {item.businessType && <div className="user-phone">{item.businessType}</div>}
                    </td>
                    <td>{item.preferredDate} {item.preferredTime && `at ${item.preferredTime}`}</td>
                    <td><span className={`status-badge ${item.seen ? "active" : "inactive"}`}>{item.seen ? "Seen" : "New"}</span></td>
                    <td><div className="date-cell">{formatDate(item.createdAt)}</div></td>
                    <td>
                      <div className="action-buttons">
                        <button className="action-btn view-btn" onClick={(e) => { e.stopPropagation(); handleViewItem(item, "demo"); }} title="View">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Side Panel */}
      {showPanel && selectedItem && (
        <>
          <div className="panel-overlay" onClick={closePanel}></div>
          <div className="side-panel">
            <div className="panel-header">
              <div className="panel-header-content">
                <h3 className="panel-title">{selectedItem._type === "contact" ? "Contact Message" : "Demo Request"}</h3>
                <p className="panel-subtitle">{selectedItem._type === "contact" ? selectedItem.name : selectedItem.fullName}</p>
              </div>
              <button className="panel-close" onClick={closePanel}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className="panel-body">
              {/* Avatar header */}
              <div className="panel-user-header">
                <div className="panel-user-avatar">
                  {(selectedItem.name || selectedItem.fullName || "?").charAt(0).toUpperCase()}
                </div>
                <div className="panel-user-info">
                  <h4>{selectedItem.name || selectedItem.fullName}</h4>
                  <p>{selectedItem.email}</p>
                  <div className="panel-user-badges">
                    <span className={`status-badge ${selectedItem.seen ? "active" : "inactive"}`}>{selectedItem.seen ? "Seen" : "New"}</span>
                    {selectedItem._type === "contact" && <span className={`inbox-priority-badge ${selectedItem.priority}`}>{selectedItem.priority}</span>}
                  </div>
                </div>
              </div>

              {selectedItem._type === "contact" ? (
                <>
                  <div className="panel-section">
                    <h5 className="section-title">Contact Information</h5>
                    <div className="info-grid">
                      <div className="info-item"><label>Email</label><span>{selectedItem.email}</span></div>
                      {selectedItem.phone && <div className="info-item"><label>Phone</label><span>{selectedItem.phone}</span></div>}
                      {selectedItem.company && <div className="info-item"><label>Company</label><span>{selectedItem.company}</span></div>}
                    </div>
                  </div>
                  {selectedItem.subject && (
                    <div className="panel-section">
                      <h5 className="section-title">Subject</h5>
                      <div className="info-grid"><div className="info-item"><span>{selectedItem.subject}</span></div></div>
                    </div>
                  )}
                  <div className="panel-section">
                    <h5 className="section-title">Message</h5>
                    <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "14px", fontSize: "14px", lineHeight: "1.6", whiteSpace: "pre-wrap", color: "#374151" }}>
                      {selectedItem.message}
                    </div>
                  </div>
                  <div className="panel-section">
                    <h5 className="section-title">Details</h5>
                    <div className="info-grid">
                      <div className="info-item"><label>Priority</label><span className={`inbox-priority-badge ${selectedItem.priority}`}>{selectedItem.priority}</span></div>
                      <div className="info-item"><label>Received</label><span>{formatDate(selectedItem.createdAt)}</span></div>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="panel-section">
                    <h5 className="section-title">Contact Information</h5>
                    <div className="info-grid">
                      <div className="info-item"><label>Email</label><span>{selectedItem.email}</span></div>
                      {selectedItem.phoneNumber && <div className="info-item"><label>Phone</label><span>{selectedItem.phoneNumber}</span></div>}
                    </div>
                  </div>
                  <div className="panel-section">
                    <h5 className="section-title">Business Information</h5>
                    <div className="info-grid">
                      <div className="info-item"><label>Business Name</label><span>{selectedItem.businessName || "—"}</span></div>
                      {selectedItem.businessType && <div className="info-item"><label>Business Type</label><span>{selectedItem.businessType}</span></div>}
                    </div>
                  </div>
                  <div className="panel-section">
                    <h5 className="section-title">Preferred Demo Time</h5>
                    <div className="info-grid">
                      <div className="info-item"><label>Date</label><span>{selectedItem.preferredDate || "—"}</span></div>
                      <div className="info-item"><label>Time</label><span>{selectedItem.preferredTime || "—"}</span></div>
                    </div>
                  </div>
                  {selectedItem.message && (
                    <div className="panel-section">
                      <h5 className="section-title">Message</h5>
                      <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "14px", fontSize: "14px", lineHeight: "1.6", whiteSpace: "pre-wrap", color: "#374151" }}>
                        {selectedItem.message}
                      </div>
                    </div>
                  )}
                  <div className="panel-section">
                    <h5 className="section-title">Details</h5>
                    <div className="info-grid">
                      <div className="info-item"><label>Received</label><span>{formatDate(selectedItem.createdAt)}</span></div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
