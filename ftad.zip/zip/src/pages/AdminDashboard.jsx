import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminDashboard.css";

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalRevenue: 0,
    totalTransactions: 0,
    totalAppointments: 0,
    recentUsers: [],
    recentTransactions: [],
    recentAppointments: [],
    usersByRole: {},
    transactionsByType: { income: 0, expense: 0 },
    appointmentsByStatus: {},
    monthlyGrowth: { users: 0, revenue: 0, appointments: 0 },
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("users");

  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) {
      navigate("/");
      return;
    }
    loadStats();
  }, [navigate]);

  const loadStats = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("adminToken");
      if (!token) { navigate("/"); return; }

      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/admin/stats`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();

      if (!data.success) {
        if (res.status === 401 || res.status === 403) {
          localStorage.removeItem("adminAuth");
          localStorage.removeItem("adminToken");
          navigate("/");
        }
        return;
      }

      setStats(data.data);
    } catch (error) {
      console.error("Error loading dashboard stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return "Never";

    let date;
    if (timestamp.toDate) {
      date = timestamp.toDate();
    } else if (typeof timestamp === "string") {
      date = new Date(timestamp);
    } else if (timestamp instanceof Date) {
      date = timestamp;
    } else {
      return "Invalid date";
    }

    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  if (loading) {
    return (
      <div className="admin-dashboard">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p className="loading-text">Loading Admin Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <div className="dashboard-header">
        <div className="header-content">
          <div className="header-title-section">
            <svg
              className="header-icon"
              width="40"
              height="40"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
            <div>
              <h1 className="dashboard-title">Admin Dashboard</h1>
              <p className="dashboard-subtitle">
                FashionTally System Overview & Analytics
              </p>
            </div>
          </div>
          <div className="header-actions">
            <button
              className="refresh-button"
              onClick={loadStats}
              disabled={loading}
            >
              <svg
                className={loading ? "spin" : ""}
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="23 4 23 10 17 10"></polyline>
                <polyline points="1 20 1 14 7 14"></polyline>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
              </svg>
              Refresh
            </button>
            <div className="status-badge">
              <svg
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
              System Online
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card stat-card-blue">
          <div className="stat-card-header">
            <span className="stat-label">Total Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.totalUsers}</div>
          <div className="stat-footer">
            <svg
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
              <polyline points="17 6 23 6 23 12" />
            </svg>
            <span>+{stats.monthlyGrowth.users} this month</span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-green">
          <div className="stat-card-header">
            <span className="stat-label">Total Revenue</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <line x1="12" y1="1" x2="12" y2="23" />
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{formatCurrency(stats.totalRevenue)}</div>
          <div className="stat-footer">
            <svg
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
              <polyline points="17 6 23 6 23 12" />
            </svg>
            <span>
              {formatCurrency(stats.monthlyGrowth.revenue)} this month
            </span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-purple">
          <div className="stat-card-header">
            <span className="stat-label">Appointments</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8" y1="2" x2="8" y2="6" />
                <line x1="3" y1="10" x2="21" y2="10" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.totalAppointments}</div>
          <div className="stat-footer">
            <svg
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
              <polyline points="17 6 23 6 23 12" />
            </svg>
            <span>+{stats.monthlyGrowth.appointments} this month</span>
          </div>
          <div className="stat-decoration"></div>
        </div>

        <div className="stat-card stat-card-orange">
          <div className="stat-card-header">
            <span className="stat-label">Active Users</span>
            <div className="stat-icon-wrapper">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
            </div>
          </div>
          <div className="stat-value">{stats.activeUsers}</div>
          <div className="stat-footer">
            <span>
              {((stats.activeUsers / stats.totalUsers) * 100).toFixed(1)}% of
              total
            </span>
          </div>
          <div className="stat-decoration"></div>
        </div>
      </div>

      {/* Analytics Section */}
      <div className="analytics-grid">
        {/* User Distribution */}
        <div className="analytics-card">
          <div className="analytics-header">
            <div className="analytics-title">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
                <path d="M22 12A10 10 0 0 0 12 2v10z" />
              </svg>
              <h3>User Distribution</h3>
            </div>
            <p className="analytics-description">Users by role</p>
          </div>
          <div className="analytics-content">
            {loading ? (
              <div className="skeleton-loader"></div>
            ) : (
              <div className="distribution-list">
                {Object.entries(stats.usersByRole).map(([role, count]) => (
                  <div key={role} className="distribution-item">
                    <div className="distribution-label">
                      <div className="distribution-dot"></div>
                      <span className="role-name">{role}</span>
                    </div>
                    <div className="distribution-value">
                      <span className="count">{count}</span>
                      <div className="progress-bar">
                        <div
                          className="progress-fill"
                          style={{
                            width: `${(count / stats.totalUsers) * 100}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Financial Overview */}
        <div className="analytics-card">
          <div className="analytics-header">
            <div className="analytics-title">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <line x1="12" y1="20" x2="12" y2="10" />
                <line x1="18" y1="20" x2="18" y2="4" />
                <line x1="6" y1="20" x2="6" y2="16" />
              </svg>
              <h3>Financial Overview</h3>
            </div>
            <p className="analytics-description">Income vs Expenses</p>
          </div>
          <div className="analytics-content">
            {loading ? (
              <div className="skeleton-loader"></div>
            ) : (
              <div className="financial-overview">
                <div className="financial-item">
                  <div className="financial-label">
                    <span className="label-text income">Income</span>
                    <span className="financial-amount">
                      {formatCurrency(stats.transactionsByType.income)}
                    </span>
                  </div>
                  <div className="progress-bar income-bar">
                    <div
                      className="progress-fill"
                      style={{ width: "75%" }}
                    ></div>
                  </div>
                </div>
                <div className="financial-item">
                  <div className="financial-label">
                    <span className="label-text expense">Expenses</span>
                    <span className="financial-amount">
                      {formatCurrency(stats.transactionsByType.expense)}
                    </span>
                  </div>
                  <div className="progress-bar expense-bar">
                    <div
                      className="progress-fill"
                      style={{ width: "25%" }}
                    ></div>
                  </div>
                </div>
                <div className="financial-total">
                  <span className="total-label">Net Profit</span>
                  <span className="total-amount profit">
                    {formatCurrency(
                      stats.transactionsByType.income -
                        stats.transactionsByType.expense
                    )}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Appointment Status */}
        <div className="analytics-card">
          <div className="analytics-header">
            <div className="analytics-title">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8" y1="2" x2="8" y2="6" />
                <line x1="3" y1="10" x2="21" y2="10" />
              </svg>
              <h3>Appointment Status</h3>
            </div>
            <p className="analytics-description">
              Current appointment distribution
            </p>
          </div>
          <div className="analytics-content">
            {loading ? (
              <div className="skeleton-loader"></div>
            ) : (
              <div className="appointment-status-list">
                {Object.entries(stats.appointmentsByStatus).map(
                  ([status, count]) => (
                    <div key={status} className="appointment-status-item">
                      <div className="status-label">
                        {status === "Completed" ? (
                          <svg
                            className="status-icon completed"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                            <polyline points="22 4 12 14.01 9 11.01" />
                          </svg>
                        ) : status === "Cancelled" ? (
                          <svg
                            className="status-icon cancelled"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <line x1="15" y1="9" x2="9" y2="15" />
                            <line x1="9" y1="9" x2="15" y2="15" />
                          </svg>
                        ) : (
                          <svg
                            className="status-icon scheduled"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <polyline points="12 6 12 12 16 14" />
                          </svg>
                        )}
                        <span className="status-name">{status}</span>
                      </div>
                      <span className="status-badge">{count}</span>
                    </div>
                  )
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Activity Tabs */}
      <div className="activity-card">
        <div className="activity-header">
          <div className="activity-title">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
              <polyline points="17 6 23 6 23 12" />
            </svg>
            <h3>Recent Activity</h3>
          </div>
          <p className="activity-description">
            Latest system activities and user interactions
          </p>
        </div>
        <div className="activity-content">
          <div className="tabs-container">
            <div className="tabs-list">
              <button
                className={`tab-button ${
                  activeTab === "users" ? "active" : ""
                }`}
                onClick={() => setActiveTab("users")}
              >
                Recent Users
              </button>
              <button
                className={`tab-button ${
                  activeTab === "transactions" ? "active" : ""
                }`}
                onClick={() => setActiveTab("transactions")}
              >
                Transactions
              </button>
              <button
                className={`tab-button ${
                  activeTab === "appointments" ? "active" : ""
                }`}
                onClick={() => setActiveTab("appointments")}
              >
                Appointments
              </button>
            </div>

            <div className="tab-content">
              {activeTab === "users" && (
                <div className="activity-list">
                  {loading
                    ? Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="activity-item skeleton">
                          <div className="skeleton-avatar"></div>
                          <div className="skeleton-content">
                            <div className="skeleton-line"></div>
                            <div className="skeleton-line short"></div>
                          </div>
                        </div>
                      ))
                    : stats.recentUsers.map((user) => (
                        <div key={user.id} className="activity-item">
                          <div className="activity-avatar">
                            {user.name
                              ? user.name.charAt(0).toUpperCase()
                              : user.email.charAt(0).toUpperCase()}
                          </div>
                          <div className="activity-details">
                            <p className="activity-name">
                              {user.name || "No name"}
                            </p>
                            <p className="activity-meta">{user.email}</p>
                          </div>
                          <div className="activity-info">
                            <span className="activity-badge">
                              {user.role || "User"}
                            </span>
                            <p className="activity-date">
                              {formatDate(user.createdAt)}
                            </p>
                          </div>
                        </div>
                      ))}
                </div>
              )}

              {activeTab === "transactions" && (
                <div className="activity-list">
                  {loading
                    ? Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="activity-item skeleton">
                          <div className="skeleton-avatar"></div>
                          <div className="skeleton-content">
                            <div className="skeleton-line"></div>
                            <div className="skeleton-line short"></div>
                          </div>
                        </div>
                      ))
                    : stats.recentTransactions.map((transaction) => (
                        <div key={transaction.id} className="activity-item">
                          <div
                            className={`activity-avatar ${
                              transaction.type === "Income"
                                ? "income"
                                : "expense"
                            }`}
                          >
                            {transaction.type === "Income" ? (
                              <svg
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                              >
                                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                                <polyline points="17 6 23 6 23 12" />
                              </svg>
                            ) : (
                              <svg
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                              >
                                <polyline points="23 18 13.5 8.5 8.5 13.5 1 6" />
                                <polyline points="17 18 23 18 23 12" />
                              </svg>
                            )}
                          </div>
                          <div className="activity-details">
                            <p className="activity-name">
                              {transaction.description}
                            </p>
                            <p className="activity-meta">
                              {transaction.category}
                            </p>
                          </div>
                          <div className="activity-info">
                            <p
                              className={`transaction-amount ${
                                transaction.type === "Income"
                                  ? "income"
                                  : "expense"
                              }`}
                            >
                              {transaction.type === "Income" ? "+" : "-"}
                              {formatCurrency(transaction.amount)}
                            </p>
                            <p className="activity-date">
                              {formatDate(transaction.createdAt)}
                            </p>
                          </div>
                        </div>
                      ))}
                </div>
              )}

              {activeTab === "appointments" && (
                <div className="activity-list">
                  {loading
                    ? Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="activity-item skeleton">
                          <div className="skeleton-avatar"></div>
                          <div className="skeleton-content">
                            <div className="skeleton-line"></div>
                            <div className="skeleton-line short"></div>
                          </div>
                        </div>
                      ))
                    : stats.recentAppointments.map((appointment) => (
                        <div key={appointment.id} className="activity-item">
                          <div className="activity-avatar appointment">
                            <svg
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                            >
                              <rect
                                x="3"
                                y="4"
                                width="18"
                                height="18"
                                rx="2"
                                ry="2"
                              />
                              <line x1="16" y1="2" x2="16" y2="6" />
                              <line x1="8" y1="2" x2="8" y2="6" />
                              <line x1="3" y1="10" x2="21" y2="10" />
                            </svg>
                          </div>
                          <div className="activity-details">
                            <p className="activity-name">
                              {appointment.clientName}
                            </p>
                            <p className="activity-meta">
                              {appointment.purpose}
                            </p>
                          </div>
                          <div className="activity-info">
                            <span
                              className={`appointment-status ${appointment.status?.toLowerCase()}`}
                            >
                              {appointment.status}
                            </span>
                            <p className="activity-date">
                              {formatDate(appointment.createdAt)}
                            </p>
                          </div>
                        </div>
                      ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      {/* <div className="quick-actions-card">
        <div className="quick-actions-header">
          <div className="quick-actions-title">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
            <h3>Admin Actions</h3>
          </div>
          <p className="quick-actions-description">
            Common administrative tasks and system management
          </p>
        </div>
        <div className="quick-actions-content">
          <div className="actions-grid">
            <button
              className="action-button primary"
              onClick={() => navigate("/dashboard/users")}
            >
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              <div className="action-text">
                <div className="action-title">Manage Users</div>
                <div className="action-subtitle">View and manage all users</div>
              </div>
            </button>

            <button className="action-button secondary">
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <ellipse cx="12" cy="5" rx="9" ry="3" />
                <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
                <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
              </svg>
              <div className="action-text">
                <div className="action-title">Database Backup</div>
                <div className="action-subtitle">Create system backup</div>
              </div>
            </button>

            <button className="action-button secondary">
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                <line x1="12" y1="9" x2="12" y2="13" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
              <div className="action-text">
                <div className="action-title">System Logs</div>
                <div className="action-subtitle">
                  View error logs and reports
                </div>
              </div>
            </button>

            <button
              className="action-button secondary"
              onClick={() => navigate("/dashboard/webhooks")}
            >
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
              <div className="action-text">
                <div className="action-title">Webhooks</div>
                <div className="action-subtitle">Monitor webhook events</div>
              </div>
            </button>

            <button
              className="action-button secondary"
              onClick={() => navigate("/dashboard/settings")}
            >
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="12" cy="12" r="10" />
                <line x1="2" y1="12" x2="22" y2="12" />
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
              </svg>
              <div className="action-text">
                <div className="action-title">System Settings</div>
                <div className="action-subtitle">Configure system settings</div>
              </div>
            </button>
          </div>
        </div>
      </div> */}
    </div>
  );
}
