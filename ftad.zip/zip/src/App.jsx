import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AdminDashboard from "./pages/AdminDashboard";
import ActiveUsers from "./pages/ActiveUsers";
import Subscriptions from "./pages/Subscriptions";
import SMSManagement from "./pages/SMSManagement";
import WebhookSMS from "./pages/WebhookSMS";
import SystemSettings from "./pages/SystemSettings";
import Payment from "./pages/Payment";
import Inbox from "./pages/Inbox";
import Notifications from "./pages/Notifications";
import ProtectedRoute from "./components/ProtectedRoute";
import "./App.css";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        >
          <Route
            index
            element={<Navigate to="/dashboard/dashboard" replace />}
          />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="users" element={<ActiveUsers />} />
          <Route path="subscriptions" element={<Subscriptions />} />
          <Route path="sms" element={<SMSManagement />} />
          <Route path="webhooks" element={<WebhookSMS />} />
          <Route path="settings" element={<SystemSettings />} />
          <Route path="inbox" element={<Inbox />} />
          <Route path="notifications" element={<Notifications />} />
          {/* Legacy routes for backward compatibility */}
          <Route
            path="active-users"
            element={<Navigate to="/dashboard/users" replace />}
          />
          <Route
            path="webhook-sms"
            element={<Navigate to="/dashboard/webhooks" replace />}
          />
          <Route
            path="management"
            element={<Navigate to="/dashboard/settings" replace />}
          />
          <Route path="payment" element={<Payment />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
